<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\Pagamento;
use App\Models\Pescador;
use App\Models\Arte;
use App\Models\ArteDoPescador;

class PagamentoController extends Controller
{
    function dados_do_recibo(string | int $id)
    {

        $divida = 0;
        $pagamentoActual = 0;
        $i = 0;
        $pagamentos_arr = [];
        $pagamentos = Pagamento::all();

        $pagamentosDoPescador = $pagamentos->where('id_pescador', $id);

        foreach ($pagamentosDoPescador as $pagamentoDoPescador) {
            $pagamentos_arr[$i] = $pagamentoDoPescador;
            $i++;
        }
        $divida = $pagamentos_arr[count($pagamentos_arr) - 1]->divida;
        $pagamentoActual = $pagamentos_arr[count($pagamentos_arr) - 1]->valor_pago;

        return [
            'divida' => $divida,
            'pagamento_actual' => $pagamentoActual,
        ];
    }

    public function gerar_recibos()
    {
        $valorAPagar = 0;
        $divida = 0;

        $pescadores = Pescador::all();
        $artes = Arte::all();
        $artesDoPescador = ArteDoPescador::all();
        $pagamentos = Pagamento::all();


        foreach ($pescadores as $pescador) {
            if (!$pescador->estado) {

                foreach ($pagamentos as $pagamento) {
                    if ($pagamento->id_pescador == $pescador->id && explode("-", $pagamento->created_at)[0] != date('Y')) {
                        if ($pagamento->pago == 0)
                            $divida += $pagamento->valor_pago;
                    }
                }

                foreach ($artesDoPescador as $arteDoPescador) {
                    if ($arteDoPescador->id_pescador == $pescador->id) {
                        foreach ($artes as $arte) {
                            if ($arteDoPescador->id_arte == $arte->id) {
                                $valorAPagar += $arte->preco;
                            }
                        }
                    }
                }
                Pagamento::create(
                    [
                        'id_pescador' => $pescador->id,
                        'divida' => $divida,
                        'valor_pago' => $valorAPagar,
                    ]
                );
            }
            $valorAPagar = 0;
            $divida = 0;
        }

        return redirect()->route('pescadores.index')->with('success', 'Recibos gerados com sucesso');
    }

    public function gerar_recibo_do_pescador(string | int $id)
    {
        $valorAPagar = 0;
        $artes = Arte::all();
        $artesDoPescador = ArteDoPescador::all()->where('id_pescador', $id);

        foreach ($artesDoPescador as $arteDoPescador) {
            foreach ($artes as $arte) {
                if ($arteDoPescador->id_arte == $arte->id) {
                    $valorAPagar += $arte->preco;
                }
            }
        }
        Pagamento::create(
            [
                'id_pescador' => $id,
                'valor_pago' => $valorAPagar,
            ]
        );
        return redirect()->route('pescadores.index')->with('success', 'Recibo gerado com sucesso');
    }

    public function create(Pescador $pescador, string | int $id)
    {


        $recibo = $this->dados_do_recibo($id);
        $divida = $recibo['divida'];

        $pagamentoActual = $recibo['pagamento_actual'];


        if (!$pescador = $pescador->where('id', $id)->first()) {
            return back()->with('error', 'Dado não encontrado');
        }
        $pescador = Pescador::find($id);

        return view('pagamentos.create', compact('divida', 'pagamentoActual', 'pescador'));
    }

    public function store(Request $request, Pagamento $pagamento, string | int $id)
    {
        $i = 0;
        $pagamentos_arr = [];


        foreach (Pagamento::all()->where('id_pescador', $id) as $pagamentoDoPescador) {
            $pagamentos_arr[$i] = $pagamentoDoPescador;
            $i++;
        }

        $pagamento = $pagamentos_arr;
        

        for ($i = 0; $i < count($pagamento); $i++) {
            $pagamento[$i]['pago'] = 1;
            $pagamento[$i]->update($request->only([
                'pago',
            ]));

        }

        return redirect()->route('pescadores.index')->with('success', 'Pagamento efectuado com sucesso');
    }
}
