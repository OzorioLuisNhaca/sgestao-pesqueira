<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\ArteDoPescadorRequestStore;
use App\Models\Pescador;
use App\Models\ArteDoPescador;
use App\Models\Arte;

class ArteDoPescadorController extends Controller
{

    public function create()
    {
        $pescador = Pescador::orderBy('id', 'desc')->first();
        $artes = Arte::all();
        $valor = 200;
        return view('artes_pescador.create', compact('pescador', 'artes', 'valor'));
    }

    public function store(ArteDoPescadorRequestStore $request)
    {
        $valor = $request->valor_pago;
        $dados = $request->validated();
        $dados['id_pescador'] = $request->id_pescador;
        $dados['tipo_de_arte'] = Arte::find($request->id_arte)->tipo_de_arte;
        ArteDoPescador::create($dados);

        if($request->mais == 1)
            return back()->with('valor', $valor);
        return redirect()->route('pescadores.create')->with('success', 'Dados adicionados com sucesso');
    }

    public function adicionar(int | string $idPescador)
    {
        $pescador = Pescador::find($idPescador);
        $artes = Arte::all();
        $valor = 200;
        return view('artes_pescador.create', compact('pescador', 'artes', 'valor'));
    }

    // public function edit(Rede $rede, string | int $id)
    // {

    //     if(!$rede = $rede->where('id', $id)->first()){
    //         return redirect()->route('pescadores.index')->with('error', 'Dado nao encontrados');
    //     }

    //     $pescador = Pescador::find($rede->id_pescador);

    //     return view('nets.edit', compact('rede', 'pescador'));
    // }
}
