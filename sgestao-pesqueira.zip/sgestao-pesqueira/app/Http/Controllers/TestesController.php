<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use App\Models\User;

class TestesController extends Controller
{
    public function graphic()
    {
        $data = [
            'labels' => ['January', 'February', 'March', 'April', 'May', 'June'],
            'data' => [69, 59, 80, 81, 56, 31],
        ];
        return view('testes.grafico', compact('data'));
    }

    public function paginacao()
    {
        //dd(DB::table('users')->orderBy('id')->simplePaginate(4));
        return view('testes.paginacao', [
            'utilizadores' => DB::table('users')->orderBy('id')->simplePaginate(3),
        ]);
    }

    public function hash()
    {
        dd(Hash::make('admin'));
    }
}
