<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Embarcacao;
use App\Models\Pescador;
use App\Models\ArteDoPescador;
use App\Models\Arte;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {

        $receitaTotal = 0;
        $novasArtes = 0;
        $antigasArtes = 0;
        $anosInicial = (int) date('Y') - 11;
        $i = 0;
        $contaArtes = [];
        $rendaPorArte = [];
        $campos = [];
        $total_artes = [];
        $anos = [];
        $receitas = [];
        
        $estatisticasDeArtes = [];

        $artes = Arte::all();
        $artesDoPescador = ArteDoPescador::all();
        $totalUtilizadores = User::all()->count();
        $totalPescadores   = Pescador::all()->count();
        $totalEmbarcacoes  = Embarcacao::all()->count();
        
        foreach(ArteDoPescador::all() as $arteDoPescador)
        {
            $receitaTotal += Arte::find($arteDoPescador->id_arte)->preco;
        }

        for($i = 0; $i < count($artes); $i++)
        {
            $campos[$i] = $artes[$i]->tipo_de_arte; 
        }

        for($i = 0; $i < count($artes); $i++)
        {
            $contaArtes[$i] = 0;
            $rendaPorArte[$i] = 0;

            for($j = 0; $j < count($artesDoPescador); $j++)
            {
                if($artesDoPescador[$j]->tipo_de_arte == $artes[$i]->tipo_de_arte){
                    $contaArtes[$i]++;
                    $rendaPorArte[$i] += Arte::find($artesDoPescador[$j]->id_arte)->preco;
                }
                    
            }

            
            $total_artes[$i] = $contaArtes[$i];

        }

        for($i = 0; $i < count($artesDoPescador); $i++)
        {

            if(explode("-", $artesDoPescador[$i]->created_at)[0] == date('Y')){
                $novasArtes++;
            }else{
                $antigasArtes++;
            }
        }

        for($i = 0; $i < 12; $i++)
        {
            $anos[$i] = $anosInicial++;
        }

        for($i = 0; $i < 12; $i++)
        {
            $receitas[$i] = 0;
            for($j = 0; $j < count($artesDoPescador); $j++)
            {
                if((int) explode("-", $artesDoPescador[$j]->created_at)[0] == $anos[$i]){
                    
                    $receitas[$i] += Arte::find($artesDoPescador[$j]->id_arte)->preco;
                }
            }
        }      
        
        $estatisticasDeArtes = [
            'campos' => $campos,
            'total_artes' => $total_artes,
            'renda_por_arte' => $rendaPorArte,
            'cores' => ['#4e73df', '#1cc88a', '#452233'],
            'novas_antigas_artes' => [$novasArtes, $antigasArtes],
            'anos' => $anos,
            'receitas' => $receitas,
        ];

        return view('home', compact(
            'totalUtilizadores',
            'totalPescadores',
            'totalEmbarcacoes',
            'receitaTotal',
            'estatisticasDeArtes',
            'i',
        ));
    }

    public function accessDenied()
    {
        return view('acesso_negado');
    }
}
