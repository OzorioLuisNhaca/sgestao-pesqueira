<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Http\Requests\PescadorRequestStore;
use App\Models\CentroDePesca;
use App\Models\Pescador;
use App\Models\Embarcacao;
use App\Models\ArteDoPescador;
use App\Models\EmbarcacaoDoPescador;
use App\Models\Pagamento;

class PescadorController extends Controller
{
    public function index()
    {
        $quantidadeDeartesPorPescador = [];
        $i = 0;
        $pescadores = DB::table('pescadors')->orderBy('id')->simplePaginate(5);
        $artes = ArteDoPescador::all();
        $pagamentos = Pagamento::all();

        // dd($pagamentos[$pagamentos->count()-1]);

        foreach($pescadores as $pescador)
        {
            foreach($artes as $arte)
            {
                if($pescador->id === $arte->id_pescador){
                    $i++;
                }
            }
            $quantidadeDeartesPorPescador[count($quantidadeDeartesPorPescador)] = $i;
            $i = 0;
        }

        // dd($pagamentos->where('id_pescador', 1)->first()->pago);

        return view('pescadores.index', compact('pescadores', 'quantidadeDeartesPorPescador', 'pagamentos', 'i'));
    }

    public function create()
    {
        $centrosDePesca = CentroDePesca::all();
        return view('pescadores.create', compact('centrosDePesca'));
    }

    public function store(PescadorRequestStore $request)
    {

        $dados = $request->validated();
        Pescador::create($dados);
        
        return redirect()->route('embarcacao-do-pescador.create');
    }


    public function show(EmbarcacaoDoPescador $embarcacaoDoPescador, string | int $id)
    { 
        $i = 0;
        $artesDoPescador = [];
        $pagamentosDoPescador = [];
        $artesDosPescadores = ArteDoPescador::all();
        $pagamentos = Pagamento::all();
        $embarcacaoDoPescador = $embarcacaoDoPescador->where('id_pescador', $id)->first();
        
        foreach($artesDosPescadores as $arteDoPescador)
        {
            if($arteDoPescador->id_pescador == $id){
                $artesDoPescador[$i++] = $arteDoPescador;
            }
        }
        
        foreach($pagamentos as $pagamento)
        {
            if($pagamento->id_pescador == $id){
                array_push($pagamentosDoPescador, $pagamento);
            }
        }

        // dd($pagamentosDoPescador[0]->divida);

        if(!$pescador = Pescador::find($id))
            return back()->with('error', 'Dados não encontrados');

        return view('pescadores.show', compact('pescador', 'embarcacaoDoPescador', 'artesDoPescador', 'i', 'pagamentosDoPescador'));
    }

    public function edit(Pescador $pescador, string | int $id)
    {
        $centrosDePesca = CentroDePesca::all();
        

        if(!$pescador = $pescador->where('id', $id)->first()){
            return redirect()->route('pescadores.index')->with('error', 'Dado não encontrados');
        }

        $centrosDePescaActualDoPescador = CentroDePesca::find($pescador->id_centro_de_pesca);
        return view('pescadores.edit', compact('pescador', 'centrosDePesca', 'centrosDePescaActualDoPescador'));
    }

    public function update(Request $request, Pescador $pescador, string | int $id)
    {
        

        if(!$pescador = $pescador->find($id)){
            return back()->with('error', 'Falha ao editar os dados');
        }

        $pescador->update($request->only([
            'nome',
            'morada',
            'id_centro_pesca',
            'bi',
        ]));

        return redirect()->route('pescadores.index')->with('success', 'Dados editados com sucesso');
    }

    public function destroy(Request $request, string | int $id)
    {
        if(!$pescador = Pescador::find($id)){
            
            return back()->with('error', 'Dados não encontrados');

        }
        $pescador['estado'] = 1;

        $pescador->update($request->only([
            'estado'
        ]));
        return redirect()->route('pescadores.index');
    }

}
