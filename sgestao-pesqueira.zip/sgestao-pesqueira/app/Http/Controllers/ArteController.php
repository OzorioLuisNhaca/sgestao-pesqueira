<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Http\Requests\ArteRequestStore;
use App\Models\Arte;

class ArteController extends Controller
{
    public function index()
    {
        $artes = DB::table('artes')->orderBy('id')->simplePaginate(5);
        return view('artes.index', compact('artes'));
    }

    public function create()
    {
        return view('artes.create');
    }

    public function store(ArteRequestStore $request)
    {
        $dados = $request->validated();
        Arte::create($dados);

        return back()->with('success', 'Dados adicionados com sucesso');
    }


    public function show(string | int $id)
    {
        if(!$arte = Arte::find($id))
            return back()->with('error', 'Dados não encontrados');

        return view('artes.show', compact('arte'));
    }

    public function edit(Arte $arte, string | int $id)
    {

        if(!$arte = $arte->where('id', $id)->first()){
            return redirect()->route('artes.index')->with('error', 'Dado não encontrado');
        }
        $id = 0;
        return view('artes.edit', compact('arte', 'id'));
    }

    public function update(Request $request, Arte $arte, string | int $id)
    {
        if(!$arte = $arte->find($id)){
            return back()->with('error', 'Falha ao editar os dados');
        }

        $arte->update($request->only([
            'tipo_de_arte',
        ]));

        return redirect()->route('artes.index')->with('success', 'Dados editados com sucesso');
    }

    public function destroy(Request $request, string | int $id)
    {
        if(!$arte = Arte::find($id)){
            
            return back()->with('error', 'Dados não encontrados');

        }
        $arte['estado'] = 1;

        $arte->update($request->only([
            'estado'
        ]));
        return redirect()->route('artes.index');
    }


}
