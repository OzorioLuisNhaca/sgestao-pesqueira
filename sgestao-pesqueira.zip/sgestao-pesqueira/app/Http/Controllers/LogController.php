<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Arte;

class LogController extends Controller
{
    public function index(Request $request)
    {   
        return view('testes.ajax');
    }

    public function store(Request $request)
    {
        $arteId = $request->id;
        $arte = Arte::updateOrCreate(
            ['id' => $arteId],
            [
                'tipo_de_arte' => $request->tipo_de_arte,
                'preco' => $request->preco,
            ]
        );

        return Response()->json($arte);
    }
}
