<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Barryvdh\DomPDF\Facade\Pdf;
use App\Models\Arte;
use App\Models\Embarcacao;
use App\Models\Pescador;
use App\Models\ArteDoPescador;
use App\Models\EmbarcacaoDoPescador;
use App\Models\Pagamento;
use App\Models\CentroDePesca;

class DocumentsController extends Controller
{
    public function pdfDocument()
    {
        $receitaTotal = 0;
        $novasArtes = 0;
        $i = 0;
        $antigasArtes = 0;
        $contaArtes = [];
        $rendaPorArte = [];
        $campos = [];
        $total_artes = [];

        $artes = Arte::all();
        $embarcacoes = Embarcacao::all();
        $pescadores = Pescador::all();
        $artesDosPescadores = ArteDoPescador::all();
        $embarcaoesDosPescadores = EmbarcacaoDoPescador::all();

        foreach (ArteDoPescador::all() as $arteDoPescador) {

            $receitaTotal += Arte::find($arteDoPescador->id_arte)->preco;
        }

        for ($i = 0; $i < count($artes); $i++) {
            $campos[$i] = $artes[$i]->tipo_de_arte;
        }

        for ($i = 0; $i < count($artes); $i++) {
            $contaArtes[$i] = 0;
            $rendaPorArte[$i] = 0;

            for ($j = 0; $j < count($artesDosPescadores); $j++) {
                if ($artesDosPescadores[$j]->tipo_de_arte == $artes[$i]->tipo_de_arte) {
                    $contaArtes[$i]++;
                    $rendaPorArte[$i] += Arte::find($artesDosPescadores[$j]->id_arte)->preco;
                }
            }


            $total_artes[$i] = $contaArtes[$i];
        }

        for ($i = 0; $i < count($artesDosPescadores); $i++) {

            if (explode("-", $artesDosPescadores[$i]->created_at)[0] == date('Y')) {
                $novasArtes++;
            } else {
                $antigasArtes++;
            }
        }

        $totalObjectos = [
            'tot_artes' => $artes->count(),
            'tot_embarcacoes' => $embarcacoes->count(),
            'tot_pescadores' => $pescadores->count(),
            'tot_artes_dos_pescadores' => $artesDosPescadores->count(),
            'tot_embarcacoes_dos_pescadores' => $embarcaoesDosPescadores->count(),
        ];

        $estatisticas = [
            'renda_por_arte' => $rendaPorArte,
            'novas_artes' => $novasArtes,
            'antigas_artes' => $antigasArtes,
            'receita_total' => $receitaTotal,

        ];

        $dados = [
            'total_de_objectos' => $totalObjectos,
            'estatisticas' => $estatisticas,
        ];

        $pdf = Pdf::loadView('documentos.pdf', [
            'dados' => $dados,
            'i' => $i,
            'artes' => $artes,
        ])->setPaper('a4');

        return $pdf->stream('relatorio.pdf');
    }

    public function recibo(string | int $id)
    {
        $pagamento = Pagamento::find($id);
        $pescador = Pescador::find($pagamento->id_pescador);

        $pdf = Pdf::loadView('documentos.recibo', [
            'pagamento' => $pagamento,
            'pescador' => $pescador,
        ])->setPaper('a5', 'landscape');

        return $pdf->stream($pescador->nome . '_' . date('Y-m-d') . '.pdf');
    }

    public function sobre_centro_de_pescas(string | int $id)
    {
        $total_de_artes = 0;
        $total_de_pescadores = 0;
        $total_de_embarcacoes = 0;
        $renda_total = 0;

        $qtddDeCdaTipo = [];
        foreach(Arte::all() as $arte)
        {
            $qtddDeCdaTipo[$arte->id - 1] = 0;
        }
        foreach (Pescador::all() as $pescador) {
            
            if ($pescador->id_centro_de_pesca == $id) {
                foreach (ArteDoPescador::all() as $arteDoPescador) {
                    if ($arteDoPescador->id_pescador == $pescador->id) {
                        foreach (Arte::all() as $arte) {
                            if ($arteDoPescador->id_arte == $arte->id){
                                $qtddDeCdaTipo[$arte->id - 1]++;
                                $renda_total += $arte->preco;
                            }        
                        }
                        $total_de_artes++;
                    }
                }

                foreach(EmbarcacaoDoPescador::all() as $embarcacao)
                {
                    if($embarcacao->id_pescador == $pescador->id){
                        $total_de_embarcacoes++;
                    }
                }
                $total_de_pescadores++;
            }
        }
        
        $dados = [
            'total_de_artes' => $total_de_artes,
            'total_de_pescadores' => $total_de_pescadores,
            'total_de_embarcacoes' => $total_de_embarcacoes,
            'renda_total' => $renda_total,
            'qtd_cada_tipo' => $qtddDeCdaTipo,
            'centro_de_pescas' => CentroDePesca::find($id),
            'i' => 0,

        ];

        

        $pdf = Pdf::loadView('documentos.centro_de_pesca', $dados)->setPaper('a4');
        return $pdf->stream(CentroDePesca::find($id)->centro_de_pesca . '_' . date('Y-m-d') . '.pdf');
    }   
}
