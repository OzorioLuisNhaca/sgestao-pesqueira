<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Models\User;

class UserController extends Controller
{
    public function index()
    {
        $utilizadores = DB::table('users')->orderBy('id')->simplePaginate(6);
        $i            = 0;

        return view('utilizadores.index', compact('utilizadores', 'i'));
    }

    public function create()
    {
        return view('utilizadores.create');
    }

    public function edit(string | int $id)
    {
        $utilizador = User::find($id);

        return view('utilizadores.edit', compact('utilizador'));
    }

    public function update(Request $request, User $utilizador, string | int $id)
    {
        
        if(!$utilizador = $utilizador->find($id)){
            return back()->with('error', 'Falha ao editar os dados');
        }


        $utilizador->update($request->only([
            'name',
            'email',
        ]));

        return redirect()->route('utilizadores.index')->with('success', 'Dados editados com sucesso');
    }

    public function destroy(Request $request, string | int $id)
    {

        if(!$utilizador = User::find($id)){
            
            return back()->with('error', 'Dados não encontrados');

        }
        $utilizador['estado'] = 1;

        $utilizador->update($request->only([
            'estado'
        ]));
        return redirect()->route('utilizadores.index');

    }
}