<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Http\Requests\EmbarcacaoRequestStore;
use App\Models\Embarcacao;

class EmbarcacaoController extends Controller
{
    public function index()
    {
        $embarcacoes = DB::table('embarcacaos')->orderBy('id')->simplePaginate(5);
        return view('embarcacoes.index', compact('embarcacoes'));
    }

    public function create()
    {
        return view('embarcacoes.create');
    }

    public function store(EmbarcacaoRequestStore $request)
    {
        $dados = $request->validated();
        Embarcacao::create($dados);

        return back()->with('success', 'Dados adicionados com sucesso');
    }


    public function show(string | int $id)
    {
        if(!$embarcacao = Embarcacao::find($id))
            return back()->with('error', 'Dados não encontrados');

        return view('embarcacoes.show', compact('embarcacao'));
    }

    public function edit(Embarcacao $embarcacao, string | int $id)
    {
        if(!$embarcacao = $embarcacao->where('id', $id)->first()){
            return redirect()->route('embarcacoes.index')->with('error', 'Dado não encontrado');
        }

        return view('embarcacoes.edit', compact('embarcacao'));
    }

    public function update(Request $request, Embarcacao $embarcacao, string | int $id)
    {
        if(!$embarcacao = $embarcacao->find($id)){
            return back()->with('error', 'Falha ao editar os dados');
        }

        $embarcacao->update($request->only([
            'tipo_de_embarcacao',
            'propulsao',
        ]));

        return redirect()->route('embarcacoes.index')->with('success', 'Dados editados com sucesso');
    }

    public function destroy(Request $request, string | int $id)
    {
        if(!$embarcacao = Embarcacao::find($id)){
            
            return back()->with('error', 'Dados não encontrados');

        }
        $embarcacao['estado'] = 1;

        $embarcacao->update($request->only([
            'estado'
        ]));
        return redirect()->route('embarcacoes.index');
    }
}
