<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Pescador;
use App\Models\Embarcacao;
use App\Models\EmbarcacaoDoPescador;
use App\Http\Requests\ArteRequestStore;
use App\Http\Requests\EmbarcacaoDoPescadorRequestStore;

class EmbarcacaoDoPescadorController extends Controller
{
 
    public function create()
    {

        $pescador = Pescador::orderBy('id', 'desc')->first();
        $embarcacoes = Embarcacao::all();
        return view('embarcacoes_pescador.create', compact('pescador', 'embarcacoes'));
    }

    public function store(EmbarcacaoDoPescadorRequestStore $request)
    {
        $dados = $request->validated();
        $dados['id_pescador'] = $request->id_pescador;
        $dados['numero_recibo'] = $request->id_pescador;
        EmbarcacaoDoPescador::create($dados);
        return redirect()->route('arte-do-pescador.create');
    }

}
