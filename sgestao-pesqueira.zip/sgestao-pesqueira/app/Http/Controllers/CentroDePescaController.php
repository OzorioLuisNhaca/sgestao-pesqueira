<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Http\Requests\CentroDePescaRequestStore;
use App\Models\CentroDePesca;
use App\Models\Arte;
use App\Models\Pescador;
use App\Models\ArteDoPescador;

class CentroDePescaController extends Controller
{
    public function index()
    {
        $centrosDePesca = DB::table('centro_de_pescas')->orderBy('id')->simplePaginate(5);
        return view('centros_de_pesca.index', compact('centrosDePesca'));
    }

    public function create()
    {
        return view('centros_de_pesca.create');
    }

    public function store(CentroDePescaRequestStore $request)
    {
        $dados = $request->validated();
        CentroDePesca::create($dados);

        return back()->with('success', 'Dados adicionados com sucesso');
    }


    public function show(string | int $id)
    {
        if(!$centroDePesca = CentroDePesca::find($id))
            return back()->with('error', 'Dados não encontrados');

        return view('centros_de_pesca.show', compact('centroDePesca'));
    }

    public function edit(CentroDePesca $centroDePesca, string | int $id)
    {
        if(!$centroDePesca = $centroDePesca->where('id', $id)->first()){
            return redirect()->route('centros-de-pesca.index')->with('error', 'Dado não encontrado');
        }

        return view('centros_de_pesca.edit', compact('centroDePesca'));
    }

    public function update(Request $request, CentroDePesca $centroDePesca, string | int $id)
    {
        if(!$centroDePesca = $centroDePesca->find($id)){
            return back()->with('error', 'Falha ao editar os dados');
        }

        $centroDePesca->update($request->only([
            'provincia',
            'distrito',
            'centro_de_pesca',
        ]));

        return redirect()->route('centros-de-pesca.index')->with('success', 'Dados editados com sucesso');
    }

    public function destroy(Request $request, string | int $id)
    {
        if(!$centroDePesca = CentroDePesca::find($id)){
            
            return back()->with('error', 'Dados não encontrados');

        }
        $centroDePesca['estado'] = 1;

        $centroDePesca->update($request->only([
            'estado'
        ]));
        return redirect()->route('centros-de-pesca.index');
    }

    public function show_statistics()
    {
        $i = 0;
        $total_de_artes = 0;
        $centros_de_pescas = [];
        $artes_do_centro_de_pescas = [];
        $arte_predominante = [];
        $dados = [];
        $qtddDeCdaTipo = []; 
        $centrosDePesca = CentroDePesca::all();
        $artes = Arte::all();
        
        
        foreach($centrosDePesca as $centroDePesca)
        {
            foreach($artes as $arte)
            {
                $qtddDeCdaTipo[$arte->id - 1] = 0;
            }
            
            foreach(Pescador::all() as $pescador)
            {
                if($pescador->id_centro_de_pesca == $centroDePesca->id){
                    foreach(ArteDoPescador::all() as $arteDoPescador)
                    {
                        if($arteDoPescador->id_pescador == $pescador->id){
                            foreach($artes as $arte)
                            {
                                if($arteDoPescador->id_arte == $arte->id)
                                    $qtddDeCdaTipo[$arte->id - 1]++;
                            }
                            $total_de_artes++;
                        }
                    }
                }
            }

            $centros_de_pescas[$i] = $centroDePesca->centro_de_pesca;
            $artes_do_centro_de_pescas[$i] = $total_de_artes;
            $arte_predominante[$i] = array_keys($qtddDeCdaTipo, max($qtddDeCdaTipo));

            $dados[$i++] = [
                'centro_de_pesca' => $centroDePesca,
                'total_de_artes' => $total_de_artes,
                'predominancia' => array_keys($qtddDeCdaTipo, max($qtddDeCdaTipo)),
            ];
              
            $total_de_artes = 0;
        }
        
        $estatisticas = [
            'cpescas' => $centros_de_pescas,
            'artes_do_centro_de_pescas' => $artes_do_centro_de_pescas,
            'arte_predominante' => $arte_predominante,
        ];

        $i = 0;
        $j = 0;
        return view('centros_de_pesca.statistics', compact(
            'dados', 
            'estatisticas',
            'i', 
            'j'
        ));
    }
}
