<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EmbarcacaoDoPescador extends Model
{
    use HasFactory;
    protected $fillable = [
        'id_pescador',
        'matricula',
        'numero_recibo',
        'licenca',
        'data_emissao',
        'propulsao',
        'estado',
    ];
}
