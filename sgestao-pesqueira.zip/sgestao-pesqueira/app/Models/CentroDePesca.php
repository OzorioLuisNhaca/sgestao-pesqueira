<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CentroDePesca extends Model
{
    use HasFactory;
    protected $fillable = [
        'provincia',
        'distrito',
        'centro_de_pesca',
        'estado',
    ];
}
