<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ArteDoPescador extends Model
{
    use HasFactory;
    protected $fillable = [
        'id_pescador',
        'tipo_de_arte',
        'comprimento',
        'id_arte',
        'malha',
        'estado',
    ];
}
