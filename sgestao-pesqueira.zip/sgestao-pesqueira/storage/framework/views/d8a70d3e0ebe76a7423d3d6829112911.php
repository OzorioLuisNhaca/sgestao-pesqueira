<?php $__env->startSection('title', 'Sistema de Licenciamento de Pescas - Emitir Rececibo de Pagamento'); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Heading -->
<h1 class="h3 mb-4 text-gray-800">Emissão de Recibo</h1>
<?php if($message = Session('success')): ?>

<div class="alert alert-success">
    <strong>
        <?php echo e($message); ?>

    </strong>
</div>

<?php endif; ?>
<!-- DataTales Example -->
<div class="card shadow my-4">
    <div
        class="card-header py-3 d-flex align-items-center justify-content-between">
        <h6 class="m-0 font-weight-bold text-primary">Emitir Recibo</h6>
    </div>
    <div class="card-body">

        <div class="row col-12">
            <form action="<?php echo e(route('pagamentos.store', $pescador->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="row">
                    <div class="col-12 col-md-12 mb-3">
                        <label for="divida" class="form-">Nome do pescador</label>
                        <select name="id_pescador" id="divida" class="form-select">
                            <option value="<?php echo e($pescador->id); ?>"><?php echo e($pescador->nome); ?></option>
                        </select>
                        <?php $__errorArgs = ['id_pescador'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                        <span class="text text-danger">
                            <strong>
                                <?php echo e($message); ?>

                            </strong>
                        </span>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-12 col-md-6 mb-3">
                        <label for="divida" class="form-">Dívida</label>
                        <input type="text" name="divida"
                            id="divida"
                            readonly
                            class="form-control <?php $__errorArgs = ['divida'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            value="<?php echo e($divida); ?>">
                        <?php $__errorArgs = ['divida'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                        <span class="text text-danger">
                            <strong>
                                <?php echo e($message); ?>

                            </strong>
                        </span>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="col-12 col-md-6 mb-3">
                        <label for="valor_pago" class="form-label">Valor a pagar</label>
                        <input type="text" name="valor_pago"
                            id="valor_pago"
                            readonly
                            class="form-control <?php $__errorArgs = ['valor_pago'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            value="<?php echo e($pagamentoActual); ?>">
                        <?php $__errorArgs = ['valo_pago'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                        <span class="text text-danger">
                            <strong>
                                <?php echo e($message); ?>

                            </strong>
                        </span>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 col-md-12 mb-3">
                        <label for="totalAPagar" class="form-label">Total a pagar</label>
                        <input type="text" id="" class="form-control" value="<?php echo e($divida  + $pagamentoActual); ?>" readonly>
                    </div>
                    <div class="mb-3 col-12 col-md-12">
                        <button type="submit"
                            class="form-control btn btn-primary">Emitir Recibo</button>
                    </div>
                </div>
                
            </form>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jcompany/Desktop/ozorio_nhaca/sg-pesqueira/resources/views/pagamentos/create.blade.php ENDPATH**/ ?>