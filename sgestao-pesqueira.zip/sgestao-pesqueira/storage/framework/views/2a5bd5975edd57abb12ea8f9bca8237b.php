

<?php $__env->startSection('title', 'Sistema de Licenciamento de Pescas - Artes'); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Heading -->
<h1 class="h4 mb-4 text-gray-800">Artes</h1>
<?php if($message = Session('success')): ?>

<div class="alert alert-success">
    <strong>
        <?php echo e($message); ?>

    </strong>
</div>

<?php endif; ?>

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div
        class="card-header py-3 d-flex align-items-center justify-content-between">
        <h6 class="m-0 font-weight-bold text-primary">Lista de Artes</h6>
        <a href="<?php echo e(route('artes.create')); ?>" class="btn btn-warning rounded-sm"
            title="Adicionar Embarcação"><i class="fa fa-plus"></i> Adicionar Arte</a>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover" id="dataTable" width="100%"
                cellspacing="0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Tipo de Arte</th>
                        <th>Acções</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $artes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arte): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(!$arte->estado): ?>
                    <tr>
                        <td><?php echo e($arte->id); ?></td>
                        <td><?php echo e($arte->tipo_de_arte); ?></td>
                        <td class="align-middle">
                            <form
                                action="<?php echo e(route('artes.destroy', $arte->id)); ?>"
                                method="POST">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <a href="<?php echo e(route('artes.show', $arte->id)); ?>"
                                    class="btn btn-success btn-sm"><i
                                        class="fa fa-eye"></i></a>
                                <a href="<?php echo e(route('artes.edit', $arte->id)); ?>"
                                    class="btn btn-primary btn-sm"><i
                                        class="fa fa-edit"></i></a>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin_access')): ?>
                                <button type="submit"
                                    class="btn btn-danger btn-sm"><i
                                        class="fa fa-trash"></i></button>
                                <?php endif; ?>
                            </form>
                        </td>
                    </tr>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php echo e($artes->onEachSide(3)->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jcompany/Desktop/ozorio_nhaca/sgestao-pesqueira/resources/views/artes/index.blade.php ENDPATH**/ ?>