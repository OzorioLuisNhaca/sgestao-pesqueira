

<?php $__env->startSection('title', 'Sistema de Licenciamento de Pescas - Cadastro Da Embarcação Do Pescador'); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Heading -->
<h1 class="h4 mb-4 text-gray-800">Cadastro Da Embarcação Do Pescador</h1>
<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div
        class="card-header py-3 d-flex align-items-center justify-content-between">
        <h6 class="m-0 font-weight-bold text-primary">Cadastrar Embarcação Do Pescador</h6>
    </div>
    <div class="card-body">

        <div class="row">
            <div class="col-12">
                <form action="<?php echo e(route('embarcacao-do-pescador.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-12 col-md-6 mb-3">
                            <label for="pescador" class="form-label">Pescador</label>
                            <select name="id_pescador" id="pescador"
                                class="form-select">
                                <option value="<?php echo e($pescador->id); ?>"><?php echo e($pescador->nome); ?></option>
                            </select>
                            <?php $__errorArgs = ['id_pescador'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                            <span class="text text-danger">
                                <strong>
                                    <?php echo e($message); ?>

                                </strong>
                            </span>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-12 col-md-6 mb-3">
                            <label for="matricula" class="form-label">Matricula</label>
                            <input type="text" name="matricula" id="matricula"
                                class="form-control <?php $__errorArgs = ['matricula'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                value="<?php echo e(old('matricula')); ?>">
                            <?php $__errorArgs = ['matricula'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                            <span class="text text-danger">
                                <strong>
                                    <?php echo e($message); ?>

                                </strong>
                            </span>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12 col-md-6 mb-3">
                            <label for="licenca" class="form-label">Licença</label>
                            <input type="text" name="licenca" id="licenca"
                                class="form-control <?php $__errorArgs = ['licenca'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                value="<?php echo e(old('licenca')); ?>">
                            <?php $__errorArgs = ['licenca'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                            <span class="text text-danger">
                                <strong>
                                    <?php echo e($message); ?>

                                </strong>
                            </span>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-12 col-md-6 mb-3">
                            <label for="propulsao" class="form-label">Propulsão</label>
                            <select name="propulsao" id class="form-select">
                                <?php $__currentLoopData = $embarcacoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $embarcacao): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option
                                    value="<?php echo e($embarcacao->tipo_de_embarcacao); ?>"><?php echo e($embarcacao->tipo_de_embarcacao); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['propulsao'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                            <span class="text text-danger">
                                <strong>
                                    <?php echo e($message); ?>

                                </strong>
                            </span>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12 col-md-12 mb-3">
                            <label for="data_emissao" class="form-label">Data de
                                Emissao</label>
                            <input type="date" name="data_emissao"
                                id="data_emissao"
                                class="form-control <?php $__errorArgs = ['data_emissao'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                value="<?php echo e(old('data_emissao')); ?>">
                            <?php $__errorArgs = ['data_emissao'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                            <span class="text text-danger">
                                <strong>
                                    <?php echo e($message); ?>

                                </strong>
                            </span>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="mb-3">
                        <button type="submit"
                            class="form-control btn btn-primary">Cadastrar</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Portal Do Codigo\Claudina\sg-pesqueira\resources\views/embarcacoes_pescador/create.blade.php ENDPATH**/ ?>