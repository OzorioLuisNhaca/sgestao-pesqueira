

<?php $__env->startSection('title', 'Sistema de Licenciamento de Pescas - Cadastrar Embarcação'); ?>

<?php $__env->startSection('content'); ?>
    <div style="width: 50%; margin: auto;">
        <canvas id="barChart"></canvas>
    </div>
    <script>
            var ctx = document.getElementById('barChart').getContext('2d');
            var myChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: <?php echo json_encode($data['labels'], 15, 512) ?>,
                    datasets: [{
                        label: 'Data',
                        data: <?php echo json_encode($data['data'], 15, 512) ?>,
                        backgroundColor: 'rgba(75, 192, 192, 0.2)',
                        borderColor: 'rgba(75, 192, 192, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Portal Do Codigo\Claudina\sg-pesqueira\resources\views/testes/grafico.blade.php ENDPATH**/ ?>