

<?php $__env->startSection('title',
'Sistema de Licenciamento de Pescas - Cadastro Dos Centros de Pesca'); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Heading -->
<h1 class="h4 mb-4 text-gray-800">Cadastrar Centro de Pesca</h1>
 <?php if($message = Session('success')): ?>

    <div class="alert alert-success">
        <strong>
            <?php echo e($message); ?>

        </strong>
    </div>

<?php endif; ?>
<!-- DataTales Example -->
<div class="card shadow my-4">
    <div
        class="card-header py-3 d-flex align-items-center justify-content-between">
        <h6 class="m-0 font-weight-bold text-primary">Cadastrar
            Centro de Pescas</h6>
    </div>
   
    <div class="card-body">

        <div class="row">
            <form action="<?php echo e(route('centros-de-pesca.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="col-12 mb-3">
                    <label for="provincia" class="form-label">Província</label>
                    <select name="provincia" id="provincia"
                        class="form-select <?php $__errorArgs = ['provincia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <option value="Maputo">Maputo</option>
                        <option value="Gaza">Gaza</option>
                        <option value="Inhambane">Inhambane</option>
                        <option value="Manica">Manica</option>
                    </select>
                    <?php $__errorArgs = ['provincia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                    <span class="text text-danger">
                        <strong>
                            <?php echo e($message); ?>

                        </strong>
                    </span>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-12 mb-3">
                    <label for="distrito" class="form-label">Distrito</label>
                    <select name="distrito" id="distrito"
                        class="form-select <?php $__errorArgs = ['distrito'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <option value="KaNyaka">KaNyaka</option>
                        <option value="KaTembe">KaTembe</option>
                        <option value="KaMpfumo">KaMpfumo</option>
                        <option value="KaMavota">KaMavota</option>
                    </select>
                    <?php $__errorArgs = ['distrito'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                    <span class="text text-danger">
                        <strong>
                            <?php echo e($message); ?>

                        </strong>
                    </span>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-12 mb-3">
                    <label for="centroDePesca" class="form-label">Centro de
                        Pescas</label>
                    <input type="text" name="centro_de_pesca" id="centroDePesca"
                        class="form-control <?php $__errorArgs = ['centro_de_pesca'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        value="<?php echo e(old('centro_de_pesca')); ?>">

                    <?php $__errorArgs = ['centro_de_pesca'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                    <span class="text text-danger">
                        <strong>
                            <?php echo e($message); ?>

                        </strong>
                    </span>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-12 mb-3">
                    <button type="submit"
                        class="form-control btn btn-primary">Cadastrar</button>
                </div>
            </form>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jcompany/Desktop/ozorio_nhaca/sgestao-pesqueira/resources/views/centros_de_pesca/create.blade.php ENDPATH**/ ?>