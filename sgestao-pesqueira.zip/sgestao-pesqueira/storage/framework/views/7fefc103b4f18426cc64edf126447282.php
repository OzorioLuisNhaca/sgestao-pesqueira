<?php $__env->startSection('title', 'Sistema de Licenciamento de Pescas - Centros De Pesca - Estatisticas'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Estatisticas</h1>
    <a href="<?php echo e(route('documento.pdf')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-60"></i> Imprimir Relatorio</a>
</div>


<!-- Content Row -->

<div class="row">

    <!-- Area Chart -->
    <div class="col-xl-10 col-lg-7 offset-xl-1">
        <div class="card shadow mb-4">
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Artes em cada centro de pescas</h6>
            </div>
            <!-- Card Body -->
            <div class="card-body">
                <div class="chart-area" style="width: 80%; margin: auto;">
                    <canvas id="fishingCenter"></canvas>
                </div>
            </div>
        </div>
    </div>

    <!-- Pie Chart -->
    <div class="col-xl-4 col-lg-5">

    </div>
</div>

<div class="card shadow mb-4">
    <div class="card-header py-3 d-flex align-items-center justify-content-between">
        <h6 class="m-0 font-weight-bold text-primary">Dados sobre centros de pescas</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover table-striped" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Centro de pescas</th>
                        <th>Artes</th>
                        <th>Predominância</th>
                        <th>Acções</th>
                    </tr>
                </thead>
                <tbody>
                    <?php for($i = 0; $i < @count($dados); $i++): ?> <tr>
                        <td><?php echo e($dados[$i]['centro_de_pesca']->centro_de_pesca); ?></td>
                        <td><?php echo e($dados[$i]['total_de_artes']); ?></td>
                        <td>
                            <?php if($dados[$i]['total_de_artes'] != 0): ?>
                            <?php for($j = 0; $j < @count($dados[$i]['predominancia']); $j++): ?> <ul>
                                <li>
                                    <?php echo e(App\Models\Arte::find($dados[$i]['predominancia'][$j] + 1)->tipo_de_arte); ?>

                                </li>
                                </ul>
                                <?php endfor; ?>
                                <?php else: ?>
                                --------------
                                <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(route('documento.sobre_centro_de_pescas', $dados[$i]['centro_de_pesca']->id)); ?>" class="btn btn-secondary" type="button">
                                <i class="fa fa-print"></i></a>
                        </td>
                        </tr>
                        <?php endfor; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
    var ctx = document.getElementById('fishingCenter').getContext('2d');
    var myChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($estatisticas['cpescas'], 15, 512) ?>,
            datasets: [{
                label: 'Total de Artes',
                data: <?php echo json_encode($estatisticas['artes_do_centro_de_pescas'], 15, 512) ?>,
                backgroundColor: 'rgba(50, 50, 200, 0.8)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jcompany/Desktop/ozorio_nhaca/sg-pesqueira/resources/views/centros_de_pesca/statistics.blade.php ENDPATH**/ ?>