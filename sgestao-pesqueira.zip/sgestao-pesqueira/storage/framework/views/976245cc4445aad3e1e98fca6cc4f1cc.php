

<?php $__env->startSection('title', 'Sistema de Licenciamento de Pescas - Cadastro De Pescadores'); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Heading -->
<h1 class="h4 mb-4 text-gray-800">Cadastro de Pescadores</h1>
<?php if($message = Session('success')): ?>

<div class="alert alert-success">
    <strong>
        <?php echo e($message); ?>

    </strong>
</div>

<?php endif; ?>
<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div
        class="card-header py-3 d-flex align-items-center justify-content-between">
        <h6 class="m-0 font-weight-bold text-primary">Cadastrar
            Pescador</h6>
    </div>
    <div class="card-body">
        <div class="row col-12 col-md-12">
            <form action="<?php echo e(route('pescadores.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-12 col-md-6 mb-3">
                        <label for="nome" class="form-label">Nome
                            do Pescador</label>
                        <input type="text" name="nome"
                            id="nome"
                            class="form-control <?php $__errorArgs = ['nome'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            value="<?php echo e(old('nome')); ?>">
                        <?php $__errorArgs = ['nome'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                        <span class="text text-danger">
                            <strong>
                                <?php echo e($message); ?>

                            </strong>
                        </span>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="col-12 col-md-6 mb-3">
                        <label for="bi" class="form-label">Bilhete de Identidade</label>
                        <input type="text" name="bi"
                            id="bi"
                            class="form-control <?php $__errorArgs = ['bi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            value="<?php echo e(old('bi')); ?>">
                        <?php $__errorArgs = ['bi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                        <span class="text text-danger">
                            <strong>
                                <?php echo e($message); ?>

                            </strong>
                        </span>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12 col-md-6 mb-3">
                        <label for="morada" class="form-label">Morada</label>
                        <input type="text" name="morada"
                            id="morada"
                            class="form-control <?php $__errorArgs = ['morada'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            value="<?php echo e(old('morada')); ?>">
                        <?php $__errorArgs = ['morada'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                        <span class="text text-danger">
                            <strong>
                                <?php echo e($message); ?>

                            </strong>
                        </span>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="col-12 col-md-6 mb-3">
                        <label for="data_nascimento" class="form-label">Data de
                            Nascimento</label>
                        <input type="date" name="data_nascimento"
                            value="<?php echo e(old('data_nascimento')); ?>"
                            id="data_nascimento"
                            class="form-control  <?php $__errorArgs = ['data_nascimento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['data_nascimento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                        <span class="text text-danger">
                            <strong>
                                <?php echo e($message); ?>

                            </strong>
                        </span>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12 col-md-6 mb-3">
                        <label for="centro_de_pesca"
                            class="form-label">Centro de
                            Pesca</label>
                        <select
                            class="form-select <?php $__errorArgs = ['id_centro_de_pesca'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="id_centro_de_pesca">
                            <?php $__currentLoopData = $centrosDePesca; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $centroDePesca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($centroDePesca->id); ?>"><?php echo e($centroDePesca->centro_de_pesca); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <?php $__errorArgs = ['id_centro_de_pesca'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                        <span class="text text-danger">
                            <strong>
                                <?php echo e($message); ?>

                            </strong>
                        </span>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                </div>

                <div class="mb-3">
                    <button type="submit"
                        class="form-control btn btn-primary">Cadastrar</button>
                </div>
            </form>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jcompany/Desktop/ozorio_nhaca/sg-pesqueira/resources/views/pescadores/create.blade.php ENDPATH**/ ?>