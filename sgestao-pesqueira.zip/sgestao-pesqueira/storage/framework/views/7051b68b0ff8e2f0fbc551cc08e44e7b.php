

<?php $__env->startSection('title', 'Sistema de Licenciamento de Pescas - Sobre O Pescador'); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Heading -->

<?php if(!$pescador->estado): ?>
<h1 class="h4 text text-info" style="text-transform: uppercase;">Pescador <?php echo e($pescador->nome); ?></h1>
<!-- DataTales Example -->
<div class="card">
    <div class="card-body">
        <!-- tabbed content -->
        <ul class="nav nav-tabs" role="tablist">
            <li class="nav-item"><a href="#dadosPessoais"
                    class="nav-link active" role="tab" data-toggle="tab">Dados
                    Pessoais Do Pescador</a></li>
            <li class="nav-item"><a href="#dadosDaEmbarcacao" class="nav-link"
                    role="tab" data-toggle="tab">Dados da Embarcação</a></li>
            <li class="nav-item"><a href="#dadosDasArtes" class="nav-link"
                    role="tab" data-toggle="tab">Dados Sobre As Artes</a></li>
            <li class="nav-item"><a href="#historicoDePagamentos" class="nav-link"
                    role="tab" data-toggle="tab">Histórico De Pagamentos</a></li>
        </ul>
        <div class="tab-content">
            <div class="tab-pane fade show active" id="dadosPessoais">

                <!-- Dados Pessoais -->
                <div class="card shadow mb-4 mt-5">
                    <div
                        class="card-header py-3 d-flex align-items-center justify-content-between">
                        <h6 class="m-0 font-weight-bold">Dados Pessoais</h6>
                    </div>
                    <div class="card-body">

                        <div class="row col-12 col-md-12">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <tr>
                                        <td>Id</td>
                                        <td><?php echo e($pescador->id); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Nome</td>
                                        <td><?php echo e($pescador->nome); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Morada</td>
                                        <td><?php echo e($pescador->morada); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Bilhete De Identidade</td>
                                        <td><?php echo e($pescador->bi); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Data De Nascimento</td>
                                        <td><?php echo e($pescador->data_nascimento); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Data de Cadastro</td>
                                        <td><?php echo e($pescador->created_at); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Data de Actualizacao</td>
                                        <td><?php echo e($pescador->updated_at); ?></td>
                                    </tr>
                                </table>
                            </div>
                        </div>

                    </div>
                </div>
                <!-- Dados Pessoais -->
            </div>
            <div class="tab-pane fade" id="dadosDaEmbarcacao">

                <!-- Dados Sobre A Embarcacao -->
                <div class="card shadow mb-4 mt-5">
                    <div
                        class="card-header py-3 d-flex align-items-center justify-content-between">
                        <h6 class="m-0 font-weight-bold">Dados da Embarcação</h6>
                    </div>
                    <div class="card-body">

                        <div class="row col-12 col-md-12">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <tr>
                                        <td>Matricula</td>
                                        <td><?php echo e($embarcacaoDoPescador->matricula); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Licença</td>
                                        <td><?php echo e($embarcacaoDoPescador->licenca); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Data de Emissão</td>
                                        <td><?php echo e($embarcacaoDoPescador->data_emissao); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Tipo de Embarcação</td>
                                        <td><?php echo e($embarcacaoDoPescador->propulsao); ?></td>
                                    </tr>
                                </table>
                            </div>
                        </div>

                    </div>
                </div>
                <!-- Dados Sobre A Embarcacao -->

            </div>
            <div class="tab-pane fade" id="dadosDasArtes">

                <!-- Dados Sobre As Artes -->
                <div class="card shadow mb-4 mt-5">
                    <div
                        class="card-header py-3 d-flex align-items-center justify-content-between">
                        <h6 class="m-0 font-weight-bold">Dados Sobre As Redes</h6>
                    </div>
                    <div class="card-body">
                        <?php for($j = 0; $j < $i; $j++): ?>
                        <div class="card my-3">

                            <div class="card-body">
                                <div class="row col-12 col-md-12">
                                    <div class="table-responsive">
                                        <table class="table table-striped">
                                            <tr>
                                                <td>Tipo de Arte</td>
                                                <td><?php echo e($artesDoPescador[$j]->tipo_de_arte); ?></td>
                                            </tr>
                                            <?php if($artesDoPescador[$j]->comprimento
                                            != ""): ?>
                                            <tr>
                                                <td>Comprimento Da Rede</td>
                                                <td><?php echo e($artesDoPescador[$j]->comprimento); ?> m</td>
                                            </tr>
                                            <tr>
                                                <td>Malha</td>
                                                <td><?php echo e($artesDoPescador[$j]->malha); ?></td>
                                            </tr>

                                            <?php endif; ?>
                                             
                                        </table>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <?php endfor; ?>

                        <div class="row">
                            <div class="col-12 ms-auto">
                                <a
                                    href="<?php echo e(route('arte-do-pescador.adicionar', [$pescador->id, $embarcacaoDoPescador])); ?>"
                                    class="btn btn-secondary"><i
                                        class="fa fa-plus"></i></a>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- Dados Sobre As Artes -->
            </div>
            <div class="tab-pane fade" id="historicoDePagamentos">

                <!-- Dados Sobre As Artes -->
                <div class="card shadow mb-4 mt-5">
                    <div
                        class="card-header py-3 d-flex align-items-center justify-content-between">
                        <h6 class="m-0 font-weight-bold">Histórico De Pagamentos</h6>
                    </div>
                    <div class="card-body">
                        <div class="card my-3">

                            <div class="card-body">
                                <div class="row col-12 col-md-12">
                                    <div class="table-responsive">
                                        <table class="table table-striped">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Ano</th>
                                                    <th>Estado Do Pagamento</th>
                                                    <th>Accoes</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php for($i = 0; $i < @count($pagamentosDoPescador); $i++): ?>
                                                    <tr>
                                                        <td><?php echo e($i+1); ?></td>
                                                        <td><?php echo e(@explode("-", $pagamentosDoPescador[$i]->created_at)[0]); ?></td>
                                                        <td>
                                                            <?php if($pagamentosDoPescador[$i]->pago): ?> 
                                                                <span class="badge bg-success">Pago</span>
                                                            <?php else: ?>
                                                                <span class="badge bg-warning">Pendente</span>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td>
                                                            <form action="<?php echo e(route('documento.recibo', $pagamentosDoPescador[$i]->id)); ?>" method="GET">
                                                                <button type="submit" class="btn btn-secondary" type="button">
                                                                    <i class="fa fa-print"></i>
                                                                </button>
                                                            </form>
                                                        </td>
                                                    </tr>
                                                <?php endfor; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>

                        </div>
                        
                        <?php if(!@explode("-", $pagamentosDoPescador[@count($pagamentosDoPescador)-1]->created_at)[0] == @date('Y')): ?>
                            <div class="row">
                                <div class="col-12 ms-auto">
                                    <a
                                        href="<?php echo e(route('pagamentos.gerar_recibo_do_pescador', $pescador->id)); ?>"
                                        class="btn btn-secondary"><i
                                            class="fa fa-plus"></i></a>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>

                </div>
                <!-- Dados Sobre As Artes -->
            </div>
        </div>
        <!-- end tabbed content -->
    </div>
</div>
<?php else: ?>
<div class="card shadow mb-4 mt-5">
    <div
        class="card-header py-3 d-flex align-items-center justify-content-between">
        <h6 class="m-0 font-weight-bold">Nada Para Mostrar</h6>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jcompany/Desktop/ozorio_nhaca/sgestao-pesqueira/resources/views/pescadores/show.blade.php ENDPATH**/ ?>