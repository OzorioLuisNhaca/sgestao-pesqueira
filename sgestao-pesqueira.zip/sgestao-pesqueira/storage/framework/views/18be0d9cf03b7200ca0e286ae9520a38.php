

<?php $__env->startSection('title', 'Sistema de Licenciamento de Pescas - Utilizadores'); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Heading -->
<?php if($message = Session('success')): ?>

<div class="alert alert-success">
    <strong>
        <?php echo e($message); ?>

    </strong>
</div>

<?php endif; ?>

<h1 class="h4 mb-4 text-gray-800">Utilizadores</h1>

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div
        class="card-header py-3 d-flex align-items-center justify-content-between">
        <h6 class="m-0 font-weight-bold text-primary">Lista dos Utilizadores</h6>
        <a href="<?php echo e(route('utilizadores.create')); ?>"
            class="btn btn-warning rounded-sm" title="Adicionar Pescador"><i
                class="fa fa-plus"></i></a>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover" id="dataTable" width="100%"
                cellspacing="0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nome</th>
                        <th>Email</th>
                        <th>Acções</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $utilizadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $utilizador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(!$utilizador->estado): ?>
                    <tr>
                        <td><?php echo e(++$i); ?></td>
                        <td><?php echo e($utilizador->name); ?></td>
                        <td><?php echo e($utilizador->email); ?></td>
                        <td>
                            <?php if($utilizador->tipo_de_utilizador != 'admin'): ?>
                            <form
                                action="<?php echo e(route('utilizadores.destroy', $utilizador->id)); ?>"
                                method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                
                                <button type="submit"
                                    class="btn btn-danger btn-sm"><i
                                        class="fa fa-trash"></i></button>
                                <a
                                    href="<?php echo e(route('utilizadores.edit', $utilizador->id)); ?>"
                                    class="btn btn-primary btn-sm"><i
                                        class="fa fa-edit"></i></a>
                            </form>
                            <?php endif; ?>
                                
                        </td>
                    </tr>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php echo e($utilizadores->onEachSide(3)->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Portal Do Codigo\Claudina\sg-pesqueira\resources\views/utilizadores/index.blade.php ENDPATH**/ ?>