<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatorio</title>
    <style>
        body{
            height: 100vh;
        }
        *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, Helvetica, sans-serif;
        }

        .container{
            width: 90%;
            margin: auto;
            padding: 20px;
        }
        hgroup{
            margin: 10px;
            margin-bottom: 50px;
        }
        .tables{
            margin-top: 50px;
        }
        .h1{
            font-size: 1em;
            text-align: center;
            letter-spacing: 1px;
            text-transform: uppercase;
            color: #5656DEDE;
            padding: 6px;
        }
        .h2{
            font-size: .8em;
            text-align: center;
            letter-spacing: 1px;
            color: #5656DEDE;
            padding: 6px;
        }
        .h3{
            margin-top: 40px;
            font-size: 1em;
        }
        .table-total{
            margin-top: 40px;
            width: 100%;
            border-spacing: 0;
        }
        tr:nth-child(even){
            background-color: lightgray;
        }
        .table-total th{
            text-align: left;
            border-bottom: solid 1px #ABABAB;
            padding: 5px;
            font-size: .8em;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .table-total td{
            padding: 5px;
            font-size: .9em;
        }
        .table-total tr td:nth-child(2){
            border-left: solid 1px #ABABAB;
            padding-left: 8px;
        }
        tr:nth-child(1){
            background-color: #5656DEDE;
            color: #fff;
        }
        footer{
            margin-top: 240px;
            text-align: center;
            font-style: italic;
        }
    </style>
</head>
<body>
    <div class="container">
        <hgroup>
            <h1 class="h1">Licenciamento De Pescas</h1>
            <h2 class="h2">Relatorio De Actividades</h2>
        </hgroup>
        <hr>
        <div class="tables">
            <h3 class="h3">Total de Entidades Cadastrados</h3>
            <table class="table-total">
                <tr>
                    <th>Dados</th>
                    <th>Total</th>
                </tr>
                <tr>
                    <td>Artes</td>
                    <td><?php echo e($dados['total_de_objectos']['tot_artes']); ?></td>
                </tr>
                <tr>
                    <td>Embarcacoes</td>
                    <td><?php echo e($dados['total_de_objectos']['tot_embarcacoes']); ?></td>
                </tr>
                <tr>
                    <td>Pescadores</td>
                    <td><?php echo e($dados['total_de_objectos']['tot_pescadores']); ?></td>
                </tr>
                <tr>
                    <td>Artes Dos Pescadores</td>
                    <td><?php echo e($dados['total_de_objectos']['tot_artes_dos_pescadores']); ?></td>
                </tr>
                <tr>
                    <td>Embarcacoes Dos Pescadores</td>
                    <td><?php echo e($dados['total_de_objectos']['tot_embarcacoes_dos_pescadores']); ?></td>
                </tr>
            </table>

            <h3 class="h3">Renda Por Arte</h3>
            <table class="table-total">
                <tr>
                    <th>Arte</th>
                    <th>Valor(MZN)</th>
                </tr>
                <?php for($i = 0; $i < @count($dados['estatisticas']['renda_por_arte']); $i++): ?>
                    <tr>
                        <td><?php echo e($artes[$i]->tipo_de_arte); ?></td>
                        <td><?php echo e($dados['estatisticas']['renda_por_arte'][$i]); ?></td>
                    </tr>
                <?php endfor; ?>
                <tr>
                    <td><b>Total</b></td>
                    <td><?php echo e($dados['estatisticas']['receita_total']); ?></td>
                </tr>
            </table>

            <h3 class="h3">Antigas e novas artes</h3>
            <table class="table-total">
                <tr>
                    <th>Antigas (antes de <?php echo e(@date('Y')); ?>)</th>
                    <th>Recentes (<?php echo e(@date('Y')); ?>)</th>
                </tr>
                <tr>
                    <td><?php echo e($dados['estatisticas']['antigas_artes']); ?></td>
                    <td><?php echo e($dados['estatisticas']['novas_artes']); ?></td>
                </tr>
            </table>
        </div>
    </div>
</body>
</html><?php /**PATH /Users/jcompany/Desktop/ozorio_nhaca/sg-pesqueira/resources/views/documentos/pdf.blade.php ENDPATH**/ ?>