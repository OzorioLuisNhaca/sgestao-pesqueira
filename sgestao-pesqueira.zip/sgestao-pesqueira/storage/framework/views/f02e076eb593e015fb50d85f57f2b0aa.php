

<?php $__env->startSection('title', 'Sistema de Licenciamento de Pescas - Edição De Embarcação'); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Heading -->
<h1 class="h3 mb-4 text-gray-800">Edição De Embarcação</h1>
<?php if($message = Session('success')): ?>

<div class="alert alert-success">
    <strong>
        <?php echo e($message); ?>

    </strong>
</div>

<?php endif; ?>
<!-- DataTales Example -->
<div class="card shadow my-4">
    <div
        class="card-header py-3 d-flex align-items-center justify-content-between">
        <h6 class="m-0 font-weight-bold text-primary">Editar Embarcação</h6>
    </div>
    <div class="card-body">

        <div class="row col-12">
            <form action="<?php echo e(route('embarcacoes.update', $embarcacao->id)); ?>"
                method="POST">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <div class="col-12 col-md-12 mb-3">
                    <label for="tipo_embarcacao" class="form-labe">Tipo de
                        Embarcação</label>
                    <input type="text" name="tipo_de_embarcacao"
                        id="tipo_embarcacao"
                        class="form-control <?php $__errorArgs = ['tipo_de_embarcacao'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        value="<?php echo e(old('tipo_de_emarcacao')); ?>">
                    <?php $__errorArgs = ['tipo_de_embarcacao'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                    <span class="text text-danger">
                        <strong>
                            <?php echo e($message); ?>

                        </strong>
                    </span>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-3">
                    <button type="submit"
                        class="form-control btn btn-primary">Cadastrar</button>
                </div>
            </form>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jcompany/Desktop/ozorio_nhaca/sg-pesqueira/resources/views/embarcacoes/edit.blade.php ENDPATH**/ ?>