<!-- Sidebar -->
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(route('home')); ?>">
        <!-- <div class="sidebar-brand-icon rotate-n-15">
            <i class="fas fa-laugh-wink"></i>
        </div> -->
        <div class="sidebar-brand-text mx-3">Licenciamento de Pesca</div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(route('home')); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Painel de Controle</span></a>
    </li>
    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->
    <div class="sidebar-heading">
        Interface
    </div>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#pescadoresCollapse" aria-expanded="true" aria-controls="pescadoresCollapse">
            <i class="fas fa-users fa-tachometer-alt"></i>
            <span>Pescadores</span></a>
        <div class="collapse" id="pescadoresCollapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-transparent py-2 collapse-inner rounded">
                <a href="<?php echo e(route('pescadores.index')); ?>" class="collapse-item text-light">
                    <i class="fas fa-users fa-tachometer-alt"></i>
                    <span>Lista de pescadores</span>
                </a>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin_access')): ?>
                <a href="#" class="collapse-item text-light">
                    <i class="fa fa-chart-line"></i>
                    <span>Estatisticas</span>
                </a>
                <?php endif; ?>
            </div>
        </div>
    </li>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin_access')): ?>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('embarcacoes.index')); ?>">
            <i class="fas fa-ship fa-tachometer-alt"></i>
            <span>Embarcações</span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('artes.index')); ?>">
            <i class="fas fa-users fa-tachometer-alt"></i>
            <span>Artes</span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="#" data-toggle="collapse" data-target="#artesCollapse" aria-expanded="true" aria-controls="artesCollapse">
            <i class="fas fa-users fa-tachometer-alt"></i>
            <span>Centro de Pesca</span></a>
        <div class="collapse" id="artesCollapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-transparent py-2 collapse-inner rounded">
                <a href="<?php echo e(route('centros-de-pesca.index')); ?>" class="collapse-item text-light">
                    <i class="fas fa-users fa-tachometer-alt"></i>
                    <span>Lista de artes</span>
                </a>
                <a href="<?php echo e(route('centros-de-pesca.show_statistics')); ?>" class="collapse-item text-light">
                    <i class="fa fa-chart-line"></i>
                    <span>Estatisticas</span>
                </a>
            </div>
        </div>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('utilizadores.index')); ?>">
            <i class="fas fa-users fa-tachometer-alt"></i>
            <span>Utilizadores</span></a>
    </li>
    <?php endif; ?>

    <hr class="sidebar-divider d-none d-md-block">

    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>

</ul>
<!-- End of Sidebar --><?php /**PATH /Users/jcompany/Desktop/ozorio_nhaca/sg-pesqueira/resources/views/componentes/sidebar.blade.php ENDPATH**/ ?>