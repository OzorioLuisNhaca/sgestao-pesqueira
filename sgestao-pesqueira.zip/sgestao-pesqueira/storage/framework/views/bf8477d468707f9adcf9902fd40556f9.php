<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatorio</title>
    <style>
        body{
            height: 100vh;
        }
        *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, Helvetica, sans-serif;
        }

        .container{
            width: 90%;
            margin: auto;
            padding: 20px;
        }
        hgroup{
            margin: 10px;
            margin-bottom: 50px;
        }
        .tables{
            margin-top: 50px;
        }
        .h1{
            font-size: 1em;
            text-align: center;
            letter-spacing: 1px;
            text-transform: uppercase;
            color: #5656DEDE;
            padding: 6px;
        }
        .h2{
            font-size: .8em;
            text-align: center;
            letter-spacing: 1px;
            color: #5656DEDE;
            padding: 6px;
        }
        .h3{
            margin-top: 40px;
            font-size: 1em;
        }
        .table-total{
            margin-top: 40px;
            width: 100%;
            border-spacing: 0;
        }
        tr:nth-child(even){
            background-color: lightgray;
        }
        .table-total th{
            text-align: left;
            border-bottom: solid 1px #ABABAB;
            padding: 5px;
            font-size: .8em;
            letter-spacing: 1px;
        }
        .table-total td{
            padding: 5px;
            font-size: .9em;
        }
        .table-total tr td:nth-child(2){
            border-left: solid 1px #ABABAB;
            padding-left: 8px;
        }
        footer{
            margin-top: 240px;
            text-align: center;
            font-style: italic;
        }
    </style>
</head>
<body>
    <div class="container">
        <hgroup>
            <h1 class="h1">Licenciamento De Pescas</h1>
            <h2 class="h2">Relatorio Do Centro De Pesca</h2>
        </hgroup>
        <hr>
        <div class="tables">
            <h3 class="h3">Centro De Pescas  : <span style="color: red;"><?php echo e($centro_de_pescas->centro_de_pesca); ?></span></h3>
            <h3 class="h3" style="margin-top: 10px;">Provincia  : <span style="color: red;"><?php echo e($centro_de_pescas->provincia); ?></span></h3>
            <h3 class="h3" style="margin-top: 10px;">Distrito  : <span style="color: red;"><?php echo e($centro_de_pescas->distrito); ?></span></h3>
            <table class="table-total">
                <tr>
                    <td>Total de Artes</td>
                    <td><?php echo e($total_de_artes); ?></td>
                </tr>
                <tr>
                    <td>Artes usadas</td>
                    <td>
                        <?php for($i = 0; $i < @count($qtd_cada_tipo); $i++): ?>
                            <ul style="padding: 5px; list-style: none;">
                                <?php if($qtd_cada_tipo[$i] != 0): ?>
                                <li>
                                    <?php echo e(App\Models\Arte::find($i + 1)->tipo_de_arte); ?>

                                </li>
                                <?php endif; ?>
                            </ul>
                        <?php endfor; ?>
                    </td>
                </tr>
                <tr>
                    <td>Pescadores</td>
                    <td><?php echo e($total_de_pescadores); ?></td>
                </tr>
                <tr>
                    <td>Embarcacoes</td>
                    <td><?php echo e($total_de_embarcacoes); ?></td>
                </tr>
            </table>
            <h3 class="h3" style="margin-top: 50px;">Renda total em <?php echo e(@date('Y' )); ?>  : <span style="color: green;"><?php echo e($renda_total); ?> MT</span></h3>
        </div>
    </div>
</body>
</html><?php /**PATH /Users/jcompany/Desktop/ozorio_nhaca/sg-pesqueira/resources/views/documentos/centro_de_pesca.blade.php ENDPATH**/ ?>