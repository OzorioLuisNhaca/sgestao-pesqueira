

<?php $__env->startSection('title', 'Sistema de Licenciamento de Pescas - Pescadores'); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Heading -->
<?php if($message = Session('success')): ?>

<div class="alert alert-success">
    <strong>
        <?php echo e($message); ?>

    </strong>
</div>

<?php endif; ?>
<h1 class="h4 mb-4 text-gray-800">Pescadores</h1>

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3 d-flex align-items-center justify-content-between">
        <h6 class="m-0 font-weight-bold text-primary">Lista de Pescadores</h6>

        <div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin_access')): ?>
            <?php if(@explode("-", $pagamentos[$pagamentos->count()-1]->created_at)[0] != @date('Y')): ?>
            <a href="<?php echo e(route('pagamentos.gerar_recibos')); ?>" class="btn btn-secondary rounded-sm" title="Gerar Recibos"><i class="fa fa-folder-open"></i></a>
            <?php endif; ?>
            <?php endif; ?>
            <a href="<?php echo e(route('pescadores.create')); ?>" class="btn btn-warning rounded-sm" title="Adicionar Pescador"><i class="fa fa-plus"> Adicionar Pescador</i></a>
        </div>

    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nome</th>
                        <th>Total de Artes</th>
                        <th>Acções</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $pescadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pescador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(!$pescador->estado): ?>
                    <tr>
                        <td><?php echo e(++$i); ?></td>
                        <td><?php echo e($pescador->nome); ?></td>
                        <td><?php echo e($quantidadeDeartesPorPescador[($pescador->id - 1)]); ?></td>
                        <td>
                            <form action="<?php echo e(route('pescadores.destroy', $pescador->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <a href="<?php echo e(route('pescadores.show', $pescador->id)); ?>" class="btn btn-success btn-sm"><i class="fa fa-eye"></i></a>
                                <a href="<?php echo e(route('pescadores.edit', $pescador->id)); ?>" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></a>

                                <?php if($pagamentos->where('id_pescador', $pescador->id)->count()): ?>
                                    <?php if($pagamentos->where('id_pescador', $pescador->id)->first()->pago != '1'): ?>
                                    <a href="<?php echo e(route('pagamentos.create', $pescador->id)); ?>" class="btn btn-warning btn-sm"><i class="fa fa-wallet text-light"></i></a>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin_access')): ?>
                                <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></button>
                                <?php endif; ?>
                            </form>
                        </td>
                    </tr>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php echo e($pescadores->onEachSide(3)->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jcompany/Desktop/ozorio_nhaca/sg-pesqueira/resources/views/pescadores/index.blade.php ENDPATH**/ ?>