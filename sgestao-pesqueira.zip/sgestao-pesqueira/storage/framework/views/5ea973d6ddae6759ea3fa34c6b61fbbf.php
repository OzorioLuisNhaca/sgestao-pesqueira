

<?php $__env->startSection('title', 'Sistema de Licenciamento de Pescas - Centros de Pescas'); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Heading -->
<h1 class="h4 mb-4 text-gray-800">Centros de Pesca</h1>
<?php if($message = Session('error')): ?>

<div class="alert alert-success">
    <strong>
        <?php echo e($message); ?>

    </strong>
</div>

<?php endif; ?>

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div
        class="card-header py-3 d-flex align-items-center justify-content-between">
        <h6 class="m-0 font-weight-bold text-primary">Lista de Centros de Pesca
            de Maputo</h6>
        <a href="<?php echo e(route('centros-de-pesca.create')); ?>"
            class="btn btn-warning rounded-sm" title="Adicionar Centro de Pesca"><i
                class="fa fa-plus"></i> Adicionar Centro de Pesca</a>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover table-striped" id="dataTable"
                width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Província</th>
                        <th>Distrito</th>
                        <th>Centro de Pesca</th>
                        <th>Acções</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $centrosDePesca; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $centroDePesca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(!$centroDePesca->estado): ?>
                    <tr>
                        <td><?php echo e($centroDePesca->id); ?></td>
                        <td><?php echo e($centroDePesca->provincia); ?></td>
                        <td><?php echo e($centroDePesca->distrito); ?></td>
                        <td><?php echo e($centroDePesca->centro_de_pesca); ?></td>
                        <td>
                            <form
                                action="<?php echo e(route('centros-de-pesca.destroy', $centroDePesca->id)); ?>"
                                method="POST">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <a
                                    href="<?php echo e(route('centros-de-pesca.show', $centroDePesca->id)); ?>"
                                    class="btn btn-success btn-sm"><i
                                        class="fa fa-eye"></i></a>
                                <a
                                    href="<?php echo e(route('centros-de-pesca.edit', $centroDePesca->id)); ?>"
                                    class="btn btn-primary btn-sm"><i
                                        class="fa fa-edit"></i></a>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin_access')): ?>
                                <button type="submit"
                                    class="btn btn-danger btn-sm"><i
                                        class="fa fa-trash"></i></button>
                                <?php endif; ?>
                            </form>
                        </td>
                    </tr>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php echo e($centrosDePesca->onEachSide(3)->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jcompany/Desktop/ozorio_nhaca/sgestao-pesqueira/resources/views/centros_de_pesca/index.blade.php ENDPATH**/ ?>