

<?php $__env->startSection('title', 'Sistema de Licenciamento de Pescas - Cadastro De Artes'); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Heading -->
<h1 class="h4 mb-4 text-gray-800">Cadastro de Artes</h1>
<?php if($message = Session('success')): ?>

    <div class="alert alert-success">
        <strong>
            <?php echo e($message); ?>

        </strong>
    </div>

<?php endif; ?>

<!-- DataTales Example -->
<div class="card shadow my-4">
    <div
        class="card-header py-3 d-flex align-items-center justify-content-between">
        <h6 class="m-0 font-weight-bold text-primary">Cadastrar
            Tipo de Arte</h6>
    </div>
    <div class="card-body">
        <div class="row col-12 col-md-12">
            <form action="<?php echo e(route('artes.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="tipoDeArte" class="form-label">Tipo de arte</label>
                    <input type="text" name="tipo_de_arte" id="tipodeArte"
                        class="form-control <?php $__errorArgs = ['tipo_de_arte'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        value="<?php echo e(old('tipo_de_arte')); ?>">
                </div>
                <?php $__errorArgs = ['tipo_de_arte'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                <span class="text text-danger">
                    <strong>
                        <?php echo e($message); ?>

                    </strong>
                </span>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <div class="mb-3">
                    <label for="valorAPagar" class="form-label">Valor A Pagar</label>
                    <input type="text" name="preco" id="valorAPagar"
                        class="form-control <?php $__errorArgs = ['preco'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        value="<?php echo e(old('preco')); ?>">
                </div>
                <?php $__errorArgs = ['preco'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                <span class="text text-danger">
                    <strong>
                        <?php echo e($message); ?>

                    </strong>
                </span>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="mb-3">
                    <button type="submit"
                        class="form-control btn btn-primary">Cadastrar</button>
                </div>
            </form>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jcompany/Desktop/ozorio_nhaca/sg-pesqueira/resources/views/artes/create.blade.php ENDPATH**/ ?>