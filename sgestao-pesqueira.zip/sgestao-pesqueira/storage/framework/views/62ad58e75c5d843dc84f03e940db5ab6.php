

<?php $__env->startSection('title', 'Sistema de Licenciamento de Pescas - Embarcações'); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Heading -->
<?php if($message = Session('success')): ?>

<div class="alert alert-success">
    <strong>
        <?php echo e($message); ?>

    </strong>
</div>

<?php endif; ?>
<h1 class="h3 mb-4 text-gray-800">Embarcações</h1>

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div
        class="card-header py-3 d-flex align-items-center justify-content-between">
        <h6 class="m-0 font-weight-bold text-primary">Lista de Embarcações</h6>
        <a href="<?php echo e(route('embarcacoes.create')); ?>"
            class="btn btn-warning rounded-sm" title="Adicionar Embarcação"><i
                class="fa fa-plus"></i> Adicionar Embarcação</a>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover" id="dataTable" width="100%"
                cellspacing="0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Tipo de Embarcação</th>
                        <th>Acções</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $embarcacoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $embarcacao): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!$embarcacao->estado): ?>
                            <tr>
                                <td><?php echo e($embarcacao->id); ?></td>
                                <td><?php echo e($embarcacao->tipo_de_embarcacao); ?> a <?php echo e($embarcacao->propulsao); ?></td>
                                <td>
                                    <form
                                        action="<?php echo e(route('embarcacoes.destroy', $embarcacao->id)); ?>"
                                        method="POST">
                                        <?php echo method_field('DELETE'); ?>
                                        <?php echo csrf_field(); ?>
                                        <a
                                            href="<?php echo e(route('embarcacoes.show', $embarcacao->id)); ?>"
                                            class="btn btn-success btn-sm"><i
                                                class="fa fa-eye"></i></a>
                                        <a
                                            href="<?php echo e(route('embarcacoes.edit', $embarcacao->id)); ?>"
                                            class="btn btn-primary btn-sm"><i
                                                class="fa fa-edit"></i></a>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin_access')): ?>
                                        <button type="submit"
                                            class="btn btn-danger btn-sm"><i
                                                class="fa fa-trash"></i></button>
                                        <?php endif; ?>
                                    </form>
                                </td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php echo e($embarcacoes->onEachSide(3)->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jcompany/Desktop/ozorio_nhaca/sgestao-pesqueira/resources/views/embarcacoes/index.blade.php ENDPATH**/ ?>