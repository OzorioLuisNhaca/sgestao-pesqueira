@extends('layouts.app')

@section('title', 'Sistema de Licenciamento de Pescas - Artes')

@section('content')
<!-- Page Heading -->
<h1 class="h4 mb-4 text-gray-800">Artes</h1>
@if($message = Session('success'))

<div class="alert alert-success">
    <strong>
        {{ $message }}
    </strong>
</div>

@endif

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div
        class="card-header py-3 d-flex align-items-center justify-content-between">
        <h6 class="m-0 font-weight-bold text-primary">Lista de Artes</h6>
        <a href="{{ route('artes.create') }}" class="btn btn-warning rounded-sm"
            title="Adicionar Embarcação"><i class="fa fa-plus"></i> Adicionar Arte</a>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover" id="dataTable" width="100%"
                cellspacing="0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Tipo de Arte</th>
                        <th>Acções</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($artes as $arte)
                    @if(!$arte->estado)
                    <tr>
                        <td>{{ $arte->id }}</td>
                        <td>{{ $arte->tipo_de_arte }}</td>
                        <td class="align-middle">
                            <form
                                action="{{ route('artes.destroy', $arte->id) }}"
                                method="POST">
                                @method('DELETE')
                                @csrf
                                <a href="{{ route('artes.show', $arte->id) }}"
                                    class="btn btn-success btn-sm"><i
                                        class="fa fa-eye"></i></a>
                                <a href="{{ route('artes.edit', $arte->id) }}"
                                    class="btn btn-primary btn-sm"><i
                                        class="fa fa-edit"></i></a>
                                @can('admin_access')
                                <button type="submit"
                                    class="btn btn-danger btn-sm"><i
                                        class="fa fa-trash"></i></button>
                                @endcan
                            </form>
                        </td>
                    </tr>
                    @endif
                    @endforeach
                </tbody>
            </table>
        </div>
        {{ $artes->onEachSide(3)->links() }}
    </div>
</div>
@endsection