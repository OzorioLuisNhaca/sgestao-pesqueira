@extends('layouts.app')

@section('title', 'Sistema de Licenciamento de Pescas - {{ $arte->tipo_de_arte }}')

@section('content')
<!-- Page Heading -->

<h3 class="text text-info" style="text-transform: uppercase;">Arte {{
    $arte->tipo_de_arte }}</h3>
<!-- DataTales Example -->
<div class="card shadow mb-4 mt-5">
    <div
        class="card-header py-3 d-flex align-items-center justify-content-between">
        <h6 class="m-0 font-weight-bold">Detalhes sobre arte</h6>
    </div>
    <div class="card-body">

        <div class="row col-12 col-md-12">
            <div class="table-responsive">
                <table class="table table-striped">
                    <tr>
                        <td>Id</td>
                        <td>{{ $arte->id }}</td>
                    </tr>
                    <tr>
                        <td>Tipo de Arte</td>
                        <td>{{ $arte->tipo_de_arte }}</td>
                    </tr>
                    <tr>
                        <td>Data de Cadastro</td>
                        <td>{{ $arte->created_at }}</td>
                    </tr>
                    <tr>
                        <td>Data de Actualizacao</td>
                        <td>{{ $arte->updated_at }}</td>
                    </tr>
                </table>
            </div>
        </div>

    </div>
</div>
@endsection