@extends('layouts.app')

@section('title', 'Sistema de Licenciamento de Pescas - Cadastro De Artes')

@section('content')
<!-- Page Heading -->
<h1 class="h4 mb-4 text-gray-800">Cadastro de Artes</h1>
@if($message = Session('success'))

    <div class="alert alert-success">
        <strong>
            {{ $message }}
        </strong>
    </div>

@endif

<!-- DataTales Example -->
<div class="card shadow my-4">
    <div
        class="card-header py-3 d-flex align-items-center justify-content-between">
        <h6 class="m-0 font-weight-bold text-primary">Cadastrar
            Tipo de Arte</h6>
    </div>
    <div class="card-body">
        <div class="row col-12 col-md-12">
            <form action="{{ route('artes.store') }}" method="POST">
                @csrf
                <div class="mb-3">
                    <label for="tipoDeArte" class="form-label">Tipo de arte</label>
                    <input type="text" name="tipo_de_arte" id="tipodeArte"
                        class="form-control @error('tipo_de_arte') is-invalid @enderror"
                        value="{{ old('tipo_de_arte') }}">
                </div>
                @error('tipo_de_arte')

                <span class="text text-danger">
                    <strong>
                        {{ $message }}
                    </strong>
                </span>

                @enderror

                <div class="mb-3">
                    <label for="valorAPagar" class="form-label">Valor A Pagar</label>
                    <input type="text" name="preco" id="valorAPagar"
                        class="form-control @error('preco') is-invalid @enderror"
                        value="{{ old('preco') }}">
                </div>
                @error('preco')

                <span class="text text-danger">
                    <strong>
                        {{ $message }}
                    </strong>
                </span>

                @enderror
                <div class="mb-3">
                    <button type="submit"
                        class="form-control btn btn-primary">Cadastrar</button>
                </div>
            </form>
        </div>

    </div>
</div>
@endsection