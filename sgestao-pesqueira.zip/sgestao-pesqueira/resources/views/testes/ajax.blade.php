<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <title>AJAX</title>
</head>

<body class="bg-gradient-primary">

    <div class="container mt-3">
        <a href="javascript:void(0)" class="btn btn-success" onclick="add()">Adicionar</a>
        @if($message = Session::get('success'))
            <div class="alert alert-success">
                <p>{{ $message }}</p>
            </div>
        @endif
        <div class="table-responsive mt-2">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Tipo</th>
                        <th>Valor a pagar</th>
                    </tr>
                </thead>
                <tbody>

                </tbody>
                
            </table>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="arte-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Artes</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
        <form action="javascript:void(0)" id="arteForm" name="arteForm" method="POST">
                <input type="hidden" name="id" id="id">
                <div class="mb-3">
                    <label for="tipoDeArte" class="form-label">Tipo de arte</label>
                    <input type="text" name="tipo_de_arte" id="tipodeArte"
                        class="form-control">
                </div>

                <div class="mb-3">
                    <label for="valorAPagar" class="form-label">Valor A Pagar</label>
                    <input type="text" name="preco" id="valorAPagar"
                        class="form-control">
                </div>

                <div class="mb-3">
                    <button type="submit"
                        class="form-control btn btn-primary" id="btn-save">Cadastrar</button>
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <!-- <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="button" class="btn btn-primary">Save changes</button> -->
            <!-- <div class="mb-3">
                    <button type="submit"
                        class="form-control btn btn-primary">Cadastrar</button>
                </div> -->
        </div>
        </div>
    </div>
    </div>
   
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.form/4.3.0/jquery.form.min.js"></script>

    <script>
        $(document).ready(function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });

        function add()
        {
            $('#arteForm').trigger("reset");
            $('#ArteModal').html("Adicionar Arte");
            $('#arte-modal').modal('show');
            $('#id').val('');
        }

        $('#arteForm').submit(function(e) {
            e.preventDefault();
            var formData = new FormData(this);

            $.ajax({
                type: 'POST',
                url: "{{ url('store') }}",
                data: formData,
                cache: false,
                contentType: false,
                processData: false,
                success: (data) => {
                    console.log(data);
                    $('#arte-modal').modal('hide');
                    $('#btn-save').html('Submit');
                    $('#btn-save').attr("disabled", false);
                },
                error: function(data){
                    console.log(data);
                }
            });
        });
    </script>

</body>

</html>