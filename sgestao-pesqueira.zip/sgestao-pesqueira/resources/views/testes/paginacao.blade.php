

@extends('layouts.app')

@section('title', 'Sistema de Licenciamento de Pescas - Cadastrar Embarcação')

@section('content')
<div class="card shadow mb-4">
    <div
        class="card-header py-3 d-flex align-items-center justify-content-between">
        <h6 class="m-0 font-weight-bold text-primary">Lista dos Utilizadores</h6>
        <a href="{{ route('utilizadores.create') }}"
            class="btn btn-warning rounded-sm" title="Adicionar Pescador"><i
                class="fa fa-plus"></i></a>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover" id="dataTable" width="100%"
                cellspacing="0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nome</th>
                        <th>Email</th>
                        <th>Acções</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($utilizadores as $utilizador)
                    <tr>
                        <td>{{ $utilizador->id }}</td>
                        <td>{{ $utilizador->name }}</td>
                        <td>{{ $utilizador->email }}</td>
                        <td>
                            @if($utilizador->tipo_de_utilizador != 'admin')
                            <form
                                action="{{ route('utilizadores.destroy', $utilizador->id) }}"
                                method="POST">
                                @csrf
                                @method('DELETE')
                                
                                <button type="submit"
                                    class="btn btn-danger btn-sm"><i
                                        class="fa fa-trash"></i></button>
                                <a
                                    href="{{ route('utilizadores.edit', $utilizador->id) }}"
                                    class="btn btn-primary btn-sm"><i
                                        class="fa fa-edit"></i></a>
                            </form>
                            @endif
                                
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>

        </div>
        {{ $utilizadores->onEachSide(5)->links() }}
    </div>
</div>
@endsection