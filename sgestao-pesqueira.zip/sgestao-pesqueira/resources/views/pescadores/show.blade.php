@extends('layouts.app')

@section('title', 'Sistema de Licenciamento de Pescas - Sobre O Pescador')

@section('content')
<!-- Page Heading -->

@if(!$pescador->estado)
<h1 class="h4 text text-info" style="text-transform: uppercase;">Pescador {{
    $pescador->nome }}</h1>
<!-- DataTales Example -->
<div class="card">
    <div class="card-body">
        <!-- tabbed content -->
        <ul class="nav nav-tabs" role="tablist">
            <li class="nav-item"><a href="#dadosPessoais"
                    class="nav-link active" role="tab" data-toggle="tab">Dados
                    Pessoais Do Pescador</a></li>
            <li class="nav-item"><a href="#dadosDaEmbarcacao" class="nav-link"
                    role="tab" data-toggle="tab">Dados da Embarcação</a></li>
            <li class="nav-item"><a href="#dadosDasArtes" class="nav-link"
                    role="tab" data-toggle="tab">Dados Sobre As Artes</a></li>
            <li class="nav-item"><a href="#historicoDePagamentos" class="nav-link"
                    role="tab" data-toggle="tab">Histórico De Pagamentos</a></li>
        </ul>
        <div class="tab-content">
            <div class="tab-pane fade show active" id="dadosPessoais">

                <!-- Dados Pessoais -->
                <div class="card shadow mb-4 mt-5">
                    <div
                        class="card-header py-3 d-flex align-items-center justify-content-between">
                        <h6 class="m-0 font-weight-bold">Dados Pessoais</h6>
                    </div>
                    <div class="card-body">

                        <div class="row col-12 col-md-12">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <tr>
                                        <td>Id</td>
                                        <td>{{ $pescador->id }}</td>
                                    </tr>
                                    <tr>
                                        <td>Nome</td>
                                        <td>{{ $pescador->nome }}</td>
                                    </tr>
                                    <tr>
                                        <td>Morada</td>
                                        <td>{{ $pescador->morada }}</td>
                                    </tr>
                                    <tr>
                                        <td>Bilhete De Identidade</td>
                                        <td>{{ $pescador->bi }}</td>
                                    </tr>
                                    <tr>
                                        <td>Data De Nascimento</td>
                                        <td>{{ $pescador->data_nascimento }}</td>
                                    </tr>
                                    <tr>
                                        <td>Data de Cadastro</td>
                                        <td>{{ $pescador->created_at }}</td>
                                    </tr>
                                    <tr>
                                        <td>Data de Actualizacao</td>
                                        <td>{{ $pescador->updated_at }}</td>
                                    </tr>
                                </table>
                            </div>
                        </div>

                    </div>
                </div>
                <!-- Dados Pessoais -->
            </div>
            <div class="tab-pane fade" id="dadosDaEmbarcacao">

                <!-- Dados Sobre A Embarcacao -->
                <div class="card shadow mb-4 mt-5">
                    <div
                        class="card-header py-3 d-flex align-items-center justify-content-between">
                        <h6 class="m-0 font-weight-bold">Dados da Embarcação</h6>
                    </div>
                    <div class="card-body">

                        <div class="row col-12 col-md-12">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <tr>
                                        <td>Matricula</td>
                                        <td>{{ $embarcacaoDoPescador->matricula }}</td>
                                    </tr>
                                    <tr>
                                        <td>Licença</td>
                                        <td>{{ $embarcacaoDoPescador->licenca }}</td>
                                    </tr>
                                    <tr>
                                        <td>Data de Emissão</td>
                                        <td>{{ $embarcacaoDoPescador->data_emissao }}</td>
                                    </tr>
                                    <tr>
                                        <td>Tipo de Embarcação</td>
                                        <td>{{ $embarcacaoDoPescador->propulsao }}</td>
                                    </tr>
                                </table>
                            </div>
                        </div>

                    </div>
                </div>
                <!-- Dados Sobre A Embarcacao -->

            </div>
            <div class="tab-pane fade" id="dadosDasArtes">

                <!-- Dados Sobre As Artes -->
                <div class="card shadow mb-4 mt-5">
                    <div
                        class="card-header py-3 d-flex align-items-center justify-content-between">
                        <h6 class="m-0 font-weight-bold">Dados Sobre As Redes</h6>
                    </div>
                    <div class="card-body">
                        @for($j = 0; $j < $i; $j++)
                        <div class="card my-3">

                            <div class="card-body">
                                <div class="row col-12 col-md-12">
                                    <div class="table-responsive">
                                        <table class="table table-striped">
                                            <tr>
                                                <td>Tipo de Arte</td>
                                                <td>{{
                                                    $artesDoPescador[$j]->tipo_de_arte
                                                    }}</td>
                                            </tr>
                                            @if($artesDoPescador[$j]->comprimento
                                            != "")
                                            <tr>
                                                <td>Comprimento Da Rede</td>
                                                <td>{{
                                                    $artesDoPescador[$j]->comprimento
                                                    }} m</td>
                                            </tr>
                                            <tr>
                                                <td>Malha</td>
                                                <td>{{ $artesDoPescador[$j]->malha
                                                    }}</td>
                                            </tr>

                                            @endif
                                             
                                        </table>
                                    </div>
                                </div>
                            </div>

                        </div>
                        @endfor

                        <div class="row">
                            <div class="col-12 ms-auto">
                                <a
                                    href="{{ route('arte-do-pescador.adicionar', [$pescador->id, $embarcacaoDoPescador]) }}"
                                    class="btn btn-secondary"><i
                                        class="fa fa-plus"></i></a>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- Dados Sobre As Artes -->
            </div>
            <div class="tab-pane fade" id="historicoDePagamentos">

                <!-- Dados Sobre As Artes -->
                <div class="card shadow mb-4 mt-5">
                    <div
                        class="card-header py-3 d-flex align-items-center justify-content-between">
                        <h6 class="m-0 font-weight-bold">Histórico De Pagamentos</h6>
                    </div>
                    <div class="card-body">
                        <div class="card my-3">

                            <div class="card-body">
                                <div class="row col-12 col-md-12">
                                    <div class="table-responsive">
                                        <table class="table table-striped">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Ano</th>
                                                    <th>Estado Do Pagamento</th>
                                                    <th>Accoes</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @for($i = 0; $i < @count($pagamentosDoPescador); $i++)
                                                    <tr>
                                                        <td>{{ $i+1 }}</td>
                                                        <td>{{ @explode("-", $pagamentosDoPescador[$i]->created_at)[0] }}</td>
                                                        <td>
                                                            @if($pagamentosDoPescador[$i]->pago) 
                                                                <span class="badge bg-success">Pago</span>
                                                            @else
                                                                <span class="badge bg-warning">Pendente</span>
                                                            @endif
                                                        </td>
                                                        <td>
                                                            <form action="{{ route('documento.recibo', $pagamentosDoPescador[$i]->id) }}" method="GET">
                                                                <button type="submit" class="btn btn-secondary" type="button">
                                                                    <i class="fa fa-print"></i>
                                                                </button>
                                                            </form>
                                                        </td>
                                                    </tr>
                                                @endfor
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>

                        </div>
                        
                        @if(!@explode("-", $pagamentosDoPescador[@count($pagamentosDoPescador)-1]->created_at)[0] == @date('Y'))
                            <div class="row">
                                <div class="col-12 ms-auto">
                                    <a
                                        href="{{ route('pagamentos.gerar_recibo_do_pescador', $pescador->id) }}"
                                        class="btn btn-secondary"><i
                                            class="fa fa-plus"></i></a>
                                </div>
                            </div>
                        @endif
                    </div>

                </div>
                <!-- Dados Sobre As Artes -->
            </div>
        </div>
        <!-- end tabbed content -->
    </div>
</div>
@else
<div class="card shadow mb-4 mt-5">
    <div
        class="card-header py-3 d-flex align-items-center justify-content-between">
        <h6 class="m-0 font-weight-bold">Nada Para Mostrar</h6>
    </div>
</div>
@endif
@endsection