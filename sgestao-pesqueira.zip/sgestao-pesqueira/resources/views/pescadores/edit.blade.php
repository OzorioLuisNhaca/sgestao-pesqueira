@extends('layouts.app')

@section('title',
'Sistema de Licenciamento de Pescas - Edição Dos Dados Do Pescador')

@section('content')
<!-- Page Heading -->
<h1 class="h4 mb-4 text-gray-800">Editar Dados Do Pescador</h1>
@if($message = Session('success'))

<div class="alert alert-success">
    <strong>
        {{ $message }}
    </strong>
</div>

@endif
<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div
        class="card-header py-3 d-flex align-items-center justify-content-between">
        <h6 class="m-0 font-weight-bold text-primary">Editar Dados Do
            Pescador</h6>
    </div>
    <div class="card-body">
        <div class="row col-12 col-md-12">
            <form action="{{ route('pescadores.update', $pescador->id) }}"
                method="POST">
                @csrf
                @method('PUT')
                <div class="row">
                    <div class="col-12 col-md-6 mb-3">
                        <label for="nome" class="form-label">Nome
                            do Pescador</label>
                        <input type="text" name="nome"
                            id="nome"
                            class="form-control @error('nome') is-invalid @enderror"
                            value="{{ $pescador->nome }}">
                        @error('nome')

                        <span class="text text-danger">
                            <strong>
                                {{ $message }}
                            </strong>
                        </span>

                        @enderror
                    </div>

                    <div class="col-12 col-md-6 mb-3">
                        <label for="bi" class="form-label">Bilhete de Identidade</label>
                        <input type="text" name="bi"
                            id="bi"
                            class="form-control @error('bi') is-invalid @enderror"
                            value="{{ $pescador->bi }}">
                        @error('bi')

                        <span class="text text-danger">
                            <strong>
                                {{ $message }}
                            </strong>
                        </span>

                        @enderror
                    </div>
                </div>

                <div class="row">
                    <div class="col-12 col-md-6 mb-3">
                        <label for="morada" class="form-label">Morada</label>
                        <input type="text" name="morada"
                            id="morada"
                            class="form-control @error('morada') is-invalid @enderror"
                            value="{{ $pescador->morada }}">
                        @error('morada')

                        <span class="text text-danger">
                            <strong>
                                {{ $message }}
                            </strong>
                        </span>

                        @enderror
                    </div>

                    <div class="col-12 col-md-6 mb-3">
                        <label for="data_nascimento" class="form-label">Data de
                            Nascimento</label>
                        <input type="date" name="data_nascimento"
                            value="{{ $pescador->data_nascimento }}"
                            id="data_nascimento"
                            class="form-control  @error('data_nascimento') is-invalid @enderror">
                        @error('data_nascimento')

                        <span class="text text-danger">
                            <strong>
                                {{ $message }}
                            </strong>
                        </span>

                        @enderror
                    </div>
                </div>

                <div class="row">
                    <div class="col-12 col-md-6 mb-3">
                        <label for="centro_de_pesca"
                            class="form-label">Centro de
                            Pesca</label>
                        <select
                            class="form-select @error('id_centro_de_pesca') is-invalid @enderror"
                            name="id_centro_de_pesca">
                            <option
                                value="{{ $centrosDePescaActualDoPescador->id }}">{{
                                $centrosDePescaActualDoPescador->centro_de_pesca
                                }}</option>
                            <option>------</option>
                            @foreach($centrosDePesca as $centroDePesca)
                            <option value="{{ $centroDePesca->id }}">{{
                                $centroDePesca->centro_de_pesca }}</option>
                            @endforeach
                        </select>

                        @error('id_centro_de_pesca')

                        <span class="text text-danger">
                            <strong>
                                {{ $message }}
                            </strong>
                        </span>

                        @enderror
                    </div>
                </div>

                <div class="mb-3">
                    <button type="submit"
                        class="form-control btn btn-primary">Actualizar</button>
                </div>
            </form>
        </div>

    </div>
</div>
@endsection