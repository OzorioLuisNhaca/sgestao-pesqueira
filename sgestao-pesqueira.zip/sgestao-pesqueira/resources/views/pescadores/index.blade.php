@extends('layouts.app')

@section('title', 'Sistema de Licenciamento de Pescas - Pescadores')

@section('content')
<!-- Page Heading -->
@if($message = Session('success'))

<div class="alert alert-success">
    <strong>
        {{ $message }}
    </strong>
</div>

@endif
<h1 class="h4 mb-4 text-gray-800">Pescadores</h1>

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3 d-flex align-items-center justify-content-between">
        <h6 class="m-0 font-weight-bold text-primary">Lista de Pescadores</h6>

        <div>
            @can('admin_access')
            @if(@explode("-", $pagamentos[$pagamentos->count()-1]->created_at)[0] != @date('Y'))
            <a href="{{ route('pagamentos.gerar_recibos') }}" class="btn btn-secondary rounded-sm" title="Gerar Recibos"><i class="fa fa-folder-open"></i></a>
            @endif
            @endcan
            <a href="{{ route('pescadores.create') }}" class="btn btn-warning rounded-sm" title="Adicionar Pescador"><i class="fa fa-plus"> Adicionar Pescador</i></a>
        </div>

    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nome</th>
                        <th>Total de Artes</th>
                        <th>Acções</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($pescadores as $pescador)
                    @if(!$pescador->estado)
                    <tr>
                        <td>{{ ++$i }}</td>
                        <td>{{ $pescador->nome }}</td>
                        <td>{{ $quantidadeDeartesPorPescador[($pescador->id - 1)] }}</td>
                        <td>
                            <form action="{{ route('pescadores.destroy', $pescador->id) }}" method="POST">
                                @csrf
                                @method('DELETE')
                                <a href="{{ route('pescadores.show', $pescador->id) }}" class="btn btn-success btn-sm"><i class="fa fa-eye"></i></a>
                                <a href="{{ route('pescadores.edit', $pescador->id) }}" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></a>

                                @if($pagamentos->where('id_pescador', $pescador->id)->count())
                                    @if($pagamentos->where('id_pescador', $pescador->id)->first()->pago != '1')
                                    <a href="{{ route('pagamentos.create', $pescador->id) }}" class="btn btn-warning btn-sm"><i class="fa fa-wallet text-light"></i></a>
                                    @endif
                                @endif
                                @can('admin_access')
                                <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></button>
                                @endcan
                            </form>
                        </td>
                    </tr>
                    @endif
                    @endforeach
                </tbody>
            </table>
        </div>
        {{ $pescadores->onEachSide(3)->links() }}
    </div>
</div>
@endsection