@extends('layouts.app')

@section('title', 'Sistema de Licenciamento de Pescas - Edição De Embarcação')

@section('content')
<!-- Page Heading -->
<h1 class="h3 mb-4 text-gray-800">Edição De Embarcação</h1>
@if($message = Session('success'))

<div class="alert alert-success">
    <strong>
        {{ $message }}
    </strong>
</div>

@endif
<!-- DataTales Example -->
<div class="card shadow my-4">
    <div
        class="card-header py-3 d-flex align-items-center justify-content-between">
        <h6 class="m-0 font-weight-bold text-primary">Editar Embarcação</h6>
    </div>
    <div class="card-body">

        <div class="row col-12">
            <form action="{{ route('embarcacoes.update', $embarcacao->id) }}"
                method="POST">
                @method('PUT')
                @csrf
                <div class="col-12 col-md-12 mb-3">
                    <label for="tipo_embarcacao" class="form-labe">Tipo de
                        Embarcação</label>
                    <input type="text" name="tipo_de_embarcacao"
                        id="tipo_embarcacao"
                        class="form-control @error('tipo_de_embarcacao') is-invalid @enderror"
                        value="{{ $embarcacao->tipo_de_embarcacao }}">
                    @error('tipo_de_embarcacao')

                    <span class="text text-danger">
                        <strong>
                            {{ $message }}
                        </strong>
                    </span>

                    @enderror
                </div>
                <div class="col-12 col-md-12 mb-3">
                    <label for="propulsao" class="form-">Propulsão</label>
                    <input type="text" name="propulsao"
                        id="tipo_embarcacao"
                        class="form-control @error('propulsao') is-invalid @enderror"
                        value="{{ $embarcacao->propulsao  }}">
                    @error('propulsao')

                    <span class="text text-danger">
                        <strong>
                            {{ $message }}
                        </strong>
                    </span>

                    @enderror
                </div>
                <div class="mb-3 col-12 col-md-12">
                    <button type="submit"
                        class="form-control btn btn-primary">Cadastrar</button>
                </div>
            </form>
        </div>

    </div>
</div>
@endsection