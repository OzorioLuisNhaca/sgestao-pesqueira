@extends('layouts.app')

@section('title', 'Sistema de Licenciamento de Pescas - Embarcações')

@section('content')
<!-- Page Heading -->
@if($message = Session('success'))

<div class="alert alert-success">
    <strong>
        {{ $message }}
    </strong>
</div>

@endif
<h1 class="h3 mb-4 text-gray-800">Embarcações</h1>

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div
        class="card-header py-3 d-flex align-items-center justify-content-between">
        <h6 class="m-0 font-weight-bold text-primary">Lista de Embarcações</h6>
        <a href="{{ route('embarcacoes.create') }}"
            class="btn btn-warning rounded-sm" title="Adicionar Embarcação"><i
                class="fa fa-plus"></i> Adicionar Embarcação</a>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover" id="dataTable" width="100%"
                cellspacing="0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Tipo de Embarcação</th>
                        <th>Acções</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($embarcacoes as $embarcacao)
                        @if(!$embarcacao->estado)
                            <tr>
                                <td>{{ $embarcacao->id }}</td>
                                <td>{{ $embarcacao->tipo_de_embarcacao }} a {{ $embarcacao->propulsao }}</td>
                                <td>
                                    <form
                                        action="{{ route('embarcacoes.destroy', $embarcacao->id) }}"
                                        method="POST">
                                        @method('DELETE')
                                        @csrf
                                        <a
                                            href="{{ route('embarcacoes.show', $embarcacao->id) }}"
                                            class="btn btn-success btn-sm"><i
                                                class="fa fa-eye"></i></a>
                                        <a
                                            href="{{ route('embarcacoes.edit', $embarcacao->id) }}"
                                            class="btn btn-primary btn-sm"><i
                                                class="fa fa-edit"></i></a>
                                        @can('admin_access')
                                        <button type="submit"
                                            class="btn btn-danger btn-sm"><i
                                                class="fa fa-trash"></i></button>
                                        @endcan
                                    </form>
                                </td>
                            </tr>
                        @endif
                    @endforeach
                </tbody>
            </table>
        </div>
        {{ $embarcacoes->onEachSide(3)->links() }}
    </div>
</div>
@endsection