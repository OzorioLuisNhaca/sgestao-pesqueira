@extends('layouts.app')

@section('title',
'Sistema de Licenciamento de Pescas - Cadastro De Utilizadores')

@section('content')
<!-- Page Heading -->
<h1 class="h4 mb-4 text-gray-800">Cadastro de Utilizadores</h1>
@if($message = Session('success'))

<div class="alert alert-success">
    <strong>
        {{ $message }}
    </strong>
</div>

@endif
<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div
        class="card-header py-3 d-flex align-items-center justify-content-between">
        <h6 class="m-0 font-weight-bold text-primary">Cadastrar
            Utilizador</h6>
    </div>
    <div class="card-body">
        <div class="row col-12 col-md-12">
            <form action="{{ route('register') }}" method="POST">
                @csrf
                <div class="row">
                    <div class="col-12 mb-3">
                        <label for="tipoDeUtilizador" class="form-label">Tipo De Utilizador</label>
                        <select name="tipo_de_utilizador" id="tipoDeUtilizador" class="form-select">
                            <option value="user">Normal</option>
                        </select>
                    </div>
                    <div class="col-12 col-md-6 mb-3">

                        <label for="nome" class="form-label">Nome do Utilizador</label>
                        <input type="text"
                            class="form-control form-control-user @error('name') is-invalid @enderror"
                            id="nome" name="name" value="{{ old('name') }}">
                        @error('name')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                        @enderror

                    </div>
                    <div class="col-12 col-md-6 mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email"
                            class="form-control form-control-user @error('email') is-invalid @enderror"
                            id="exampleInputEmail" name="email"
                            value="{{ old('email') }}">

                        @error('email')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                        @enderror

                    </div>
                </div>

                <div class="row">
                        <div class="col-12 mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="text"
                                class="form-control form-control-user @error('password') is-invalid @enderror"
                                name="password" required
                                autocomplete="new-password"
                                id="password"
                                value="utilizador123"
                                oninput="mudarSenha()">
                            @error('password')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                            @enderror
                        </div>
                        <div class="col-12">
                            <input type="hidden"
                                class="form-control form-control-user"
                                name="password_confirmation" required
                                autocomplete="new-password"
                                id="repetirPassword"
                                value="utilizador123">
                        </div>
                </div>

                <div class="mb-3">
                    <button type="submit"
                        class="form-control btn btn-primary">Cadastrar Utilizador</button>
                </div>
            </form>
        </div>

    </div>
</div>

<script>
    function mudarSenha()
    {
        let senhaActual = document.getElementById('password').value;
        document.getElementById('repetirPassword').value = senhaActual;
    }
</script>
@endsection