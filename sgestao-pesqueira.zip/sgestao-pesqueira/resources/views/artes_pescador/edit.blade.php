@extends('layouts.app')

@section('title',
'Sistema de Licenciamento de Pescas - Edição Da Arte Do Pescador')

@section('content')
<!-- Page Heading -->
<h1 class="h4 mb-4 text-gray-800">{{ $pescador->nome }}</h1>

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3 d-flex align-items-center justify-content-between">
        <h6 class="m-0 font-weight-bold text-primary">Cadastrar
            Artes</h6>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-12">
                <form action="{{ route('artes_pescador.update', $arteDoPescador->id) }}" method="POST">
                    @csrf
                    <div class="row">
                        <input type="hidden" name="id_pescador" value="{{ $pescador->id }}">

                        <label for="pescador" class="form-label">Nome da Embarcação</label>
                        <input type="text" class="form-control" value="{{ $embarcacao->nome_da_embarcao }}" readonly>
                        @error('id_pescador')

                        <span class="text text-danger">
                            <strong>
                                {{ $message }}
                            </strong>
                        </span>

                        @enderror
                    </div>
            </div>
            <div id="artes">
                <div class="card my-3">
                    <div class="card-body bg-light">

                        <div class="row">
                            <div class="col-12 mb-3">
                                <label for="tipoDeArte" class="form-label">Tipo De Arte</label>
                                <select name="id_arte" id="tipoDeArte" oninput="valorAPagar()" class="form-select">
                                    <option value="{{ $arteDoPescador->id }}">{{
                                                $rede->tipo_de_arte }}</option>
                                    <optin>-----</option>
                                </select>
                                @error('id_arte')

                                <span class="text text-danger">
                                    <strong>
                                        {{ $message }}
                                    </strong>
                                </span>

                                @enderror
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12 col-md-6 mb-3">
                                <label for="comprimento" class="form-label">Comprimento</label>
                                <input type="text" name="comprimento" id="comprimento" class="form-control @error('comprimento') is-invalid @enderror" value="{{ $arteDoPescador->comprimento }}" readonly>
                                @error('comprimento')

                                <span class="text text-danger">
                                    <strong>
                                        {{ $message }}
                                    </strong>
                                </span>

                                @enderror
                            </div>

                            <div class="col-12 col-md-6 mb-3">
                                <label for="malha" class="form-label">Malha</label>
                                <input type="text" name="malha" id="malha" class="form-control @error('malha') is-invalid @enderror" value="{{ $arteDoPescador->malha }}" readonly>
                                @error('malha')

                                <span class="text text-danger">
                                    <strong>
                                        {{ $message }}
                                    </strong>
                                </span>

                                @enderror
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-12 col-md-12 mb-3">
                                <label for="valorPago" class="form-label">Valor a Pagar</label>
                                <input type="text" name="valor_pago" id="valorPago" class="form-control" value="{{ $arteDoPescador->valor_pago }}" readonly>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="mb-3">
                    <button type="submit" class="form-control btn btn-primary">Cadastrar</button>
                </div>

                </form>
            </div>
        </div>

    </div>
</div>

<script>
    function valorAPagar() {
        let valorPago = document.getElementById("valorPago");
        let tipoDeArte = document.getElementById("tipoDeArte").value;
        let comprimento = document.getElementById("comprimento");
        let malha = document.getElementById("malha");

        if (tipoDeArte == "1") {

            valorPago.value = "200";
            comprimento.readOnly = true;
            malha.readOnly = true;

        } else if (tipoDeArte == "2") {

            valorPago.value = "450";
            comprimento.readOnly = false;
            malha.readOnly = false;
        }



    }
</script>
@endsection