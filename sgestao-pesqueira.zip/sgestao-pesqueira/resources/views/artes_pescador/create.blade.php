@extends('layouts.app')

@section('title', 'Sistema de Licenciamento de Pescas - Cadastro Da Arte Do Pescador')

@section('content')
<!-- Page Heading -->
<h1 class="h4 mb-4 text-gray-800">{{ $pescador->nome }}</h1>

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div
        class="card-header py-3 d-flex align-items-center justify-content-between">
        <h6 class="m-0 font-weight-bold text-primary">Cadastrar
            Artes</h6>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-12">
                <form action="{{ route('arte-do-pescador.store') }}" method="POST">
                    @csrf
                    <div class="row">
                        <div class="col-12 mb-3">
                            <input type="hidden" name="id_pescador" value="{{ $pescador->id }}">

                            <label for="pescador" class="form-label">Nome da Embarcação</label>
                            <input type="text" class="form-control" value="{{ $embarcacao->nome_da_embarcao }}" readonly>
                            @error('id_pescador')

                            <span class="text text-danger">
                                <strong>
                                    {{ $message }}
                                </strong>
                            </span>

                            @enderror
                        </div>
                    </div>
                    <div id="artes">
                        <div class="card my-3">
                            <div class="card-body bg-light">

                                <div class="row">
                                    <div class="col-12 mb-3">
                                        <label for="tipoDeArte"
                                            class="form-label">Tipo De Arte</label>
                                        <select name="id_arte" id="tipoDeArte"
                                            oninput="valorAPagar()"
                                            class="form-select">
                                            @foreach($artes as $arte)
                                            <option value="{{ $arte->id }}">{{
                                                $arte->tipo_de_arte }}</option>
                                            @endforeach
                                        </select>
                                        @error('id_arte')

                                        <span class="text text-danger">
                                            <strong>
                                                {{ $message }}
                                            </strong>
                                        </span>

                                        @enderror
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12 col-md-6 mb-3">
                                        <label for="comprimento"
                                            class="form-label">Comprimento</label>
                                        <input type="text" name="comprimento"
                                            id="comprimento"
                                            class="form-control @error('comprimento') is-invalid @enderror"
                                            value="{{ old('comprimento') }}"
                                            >
                                        @error('comprimento')

                                        <span class="text text-danger">
                                            <strong>
                                                {{ $message }}
                                            </strong>
                                        </span>

                                        @enderror
                                    </div>

                                    <div class="col-12 col-md-6 mb-3">
                                        <label for="malha" class="form-label">Malha</label>
                                        <input type="text" name="malha"
                                            id="malha"
                                            class="form-control @error('malha') is-invalid @enderror"
                                            value="{{ old('malha') }}">
                                        @error('malha')

                                        <span class="text text-danger">
                                            <strong>
                                                {{ $message }}
                                            </strong>
                                        </span>

                                        @enderror
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12 col-md-6 mb-0">
                                        <label for="cadastrarMais"
                                            class="form-label">
                                            <input type="radio"
                                                class="@error('mais') is-invalid @enderror"
                                                name="mais" id="cadastrarMais"
                                                value="1">
                                            Cadastrar Mais
                                        </label>

                                    </div>

                                    <div class="col-12 col-md-6 mb-0">
                                        <label for="naoCadastrar"
                                            class="form-check">
                                            <input type="radio"
                                                class="@error('mais') is-invalid @enderror"
                                                name="mais" id="naoCadastrar"
                                                value="0">
                                            Nao Cadastrar Mais
                                        </label>

                                    </div>

                                    <div class="col-12 mb-3">
                                        @error('mais')

                                        <span class="text text-danger">
                                            <strong>
                                                {{ $message }}
                                            </strong>
                                        </span>

                                        @enderror
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12 col-md-12 mb-3">
                                        <label for="valorPago"
                                            class="form-label">Valor a Pagar</label>
                                        <input type="text"
                                            id="valorPago" class="form-control"
                                            value="{{ 500 }}" readonly>
                                    </div>
                                </div>

                                <div class="col-12 col-md-6 mb-0">
                                        <label for="naoCadastrar"
                                            class="form-check">
                                            <input type="hidden" id="id_da_arte" value="0">
                                        </label>

                                </div>
                                
                            </div>

                        </div>

                        <div class="mb-3">
                            <button type="submit"
                                class="form-control btn btn-primary">Cadastrar</button>
                        </div>

                    </form>
                </div>
            </div>

        </div>
    </div>
    <?php 
        $id = 0;
        
    ?>
    <script>
        
        
        document.getElementById("id_da_arte").value  = document.getElementById("tipoDeArte").value;
        function valorAPagar(price)
        {
            let valorPago = document.getElementById("valorPago");
            var tipoDeArte = document.getElementById("tipoDeArte").value;
            let comprimento = document.getElementById("comprimento");
            let malha = document.getElementById("malha");
            let idDaarte = document.getElementById("id_da_arte");
            

            if(tipoDeArte == "1"){

                valorPago.value = 500;
                comprimento.readOnly = false;
                malha.readOnly = false;

            }else if(tipoDeArte == "2"){

                valorPago.value = 200;
                comprimento.readOnly = true;
                malha.readOnly = true;
            }

        }
    </script>
@endsection