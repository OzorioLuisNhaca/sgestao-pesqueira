<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatorio</title>
    <style>
        body{
            height: 100vh;
        }
        *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, Helvetica, sans-serif;
        }

        .container{
            width: 90%;
            margin: auto;
            padding: 20px;
        }
        hgroup{
            margin: 10px;
            margin-bottom: 50px;
        }
        .tables{
            margin-top: 50px;
        }
        .h1{
            font-size: 1em;
            text-align: center;
            letter-spacing: 1px;
            text-transform: uppercase;
            color: #5656DEDE;
            padding: 6px;
        }
        .h2{
            font-size: .8em;
            text-align: center;
            letter-spacing: 1px;
            color: #5656DEDE;
            padding: 6px;
        }
        .h3{
            margin-top: 40px;
            font-size: 1em;
        }
        .table-total{
            margin-top: 40px;
            width: 100%;
            border-spacing: 0;
        }
        tr:nth-child(even){
            background-color: lightgray;
        }
        .table-total th{
            text-align: left;
            border-bottom: solid 1px #ABABAB;
            padding: 5px;
            font-size: .8em;
            letter-spacing: 1px;
        }
        .table-total td{
            padding: 5px;
            font-size: .9em;
        }
        .table-total tr td:nth-child(2){
            border-left: solid 1px #ABABAB;
            padding-left: 8px;
        }
        footer{
            margin-top: 240px;
            text-align: center;
            font-style: italic;
        }
    </style>
</head>
<body>
    <div class="container">
        <hgroup>
            <h1 class="h1">Licenciamento De Pescas</h1>
            <h2 class="h2">Recibo de pagamento de licenca</h2>
        </hgroup>
        <hr>
        <div class="tables">
            <h3 class="h3">Recibo ........................................................................................................................................ <span style="color: red;">n<sup>o</sup> {{ $pagamento->id }}</span></h3>
            <table class="table-total">
                <tr>
                    <td>Divida</td>
                    <td>{{ $pagamento->divida }}</td>
                </tr>
                <tr>
                    <td>Pagamento deste ano</td>
                    <td>{{ $pagamento->valor_pago }}</td>
                </tr>
                <tr>
                    <td>Pagamento Total</td>
                    <td>{{ $pagamento->divida + $pagamento->valor_pago }}</td>
                </tr>
                <tr>
                    <td>Estado do pagamento</td>
                    <td>{{ $pagamento->pago ? 'Pago' : 'Pagamento pendente' }}</td>
                </tr>
            </table>
        </div>
    </div>
</body>
</html>