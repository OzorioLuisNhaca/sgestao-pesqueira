@extends('layouts.app')

@section('title', 'Sistema de Licenciamento de Pescas - Edição Da Embarcação Do Pescador')

@section('content')
<!-- Page Heading -->
<h1 class="h4 mb-4 text-gray-800">Edição Da Embarcação Do Pescador</h1>
<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div
        class="card-header py-3 d-flex align-items-center justify-content-between">
        <h6 class="m-0 font-weight-bold text-primary">Editar Embarcação Do Pescador</h6>
    </div>
    <div class="card-body">

        <div class="row">
            <div class="col-12">
                <form action="{{ route('embarcaoes_pescador.update', $embarcaoDoPescador->id) }}" method="POST">
                    @csrf
                    <div class="row">
                        <div class="col-12 col-md-6 mb-3">
                            <label for="pescador" class="form-label">Pescador</label>
                            <select name="id_pescador" id="pescador"
                                class="form-select">
                                <option value="{{ $pescador->id }}">{{
                                    $pescador->nome }}</option>
                            </select>
                            @error('id_pescador')

                            <span class="text text-danger">
                                <strong>
                                    {{ $message }}
                                </strong>
                            </span>

                            @enderror
                        </div>

                        <div class="col-12 col-md-6 mb-3">
                            <label for="matricula" class="form-label">Matricula</label>
                            <input type="text" name="matricula" id="matricula"
                                class="form-control @error('matricula') is-invalid @enderror" 
                                value="{{ $embarcaoDoPescador->matricula }}">
                            @error('matricula')

                            <span class="text text-danger">
                                <strong>
                                    {{ $message }}
                                </strong>
                            </span>

                            @enderror
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12 col-md-6 mb-3">
                            <label for="licenca" class="form-label">Licença</label>
                            <input type="text" name="licenca" id="licenca"
                                class="form-control @error('licenca') is-invalid @enderror" 
                                value="{{ $embarcaoDoPescador->licenca }}">
                            @error('licenca')

                            <span class="text text-danger">
                                <strong>
                                    {{ $message }}
                                </strong>
                            </span>

                            @enderror
                        </div>

                        <div class="col-12 col-md-6 mb-3">
                            <label for="propulsao" class="form-label">Tipo De Embarcacão</label>
                            <select name="propulsao" id class="form-select">
                                <option value="{{ $embarcaoDoPescador->tipo_de_embarcacao }}"></option>
                                @foreach($embarcacoes as $embarcacao)
                                <option
                                    value="{{ $embarcacao->tipo_de_embarcacao }}">{{
                                    $embarcacao->tipo_de_embarcacao }}</option>
                                @endforeach
                            </select>
                            @error('propulsao')

                            <span class="text text-danger">
                                <strong>
                                    {{ $message }}
                                </strong>
                            </span>

                            @enderror
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12 col-md-12 mb-3">
                            <label for="data_emissao" class="form-label">Data de
                                Emissao</label>
                            <input type="date" name="data_emissao"
                                id="data_emissao"
                                class="form-control @error('data_emissao') is-invalid @enderror"
                                value="{{ $embarcaoDoPescador->data_de_emissao }}">
                            @error('data_emissao')

                            <span class="text text-danger">
                                <strong>
                                    {{ $message }}
                                </strong>
                            </span>

                            @enderror
                        </div>
                    </div>
                    <div class="mb-3">
                        <button type="submit"
                            class="form-control btn btn-primary">Cadastrar</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
</div>
@endsection