@extends('layouts.app')

@section('title',
'Sistema de Licenciamento de Pescas - Cadastro Dos Centros de Pesca')

@section('content')
<!-- Page Heading -->
<h1 class="h4 mb-4 text-gray-800">Cadastrar Centro de Pesca</h1>
 @if($message = Session('success'))

    <div class="alert alert-success">
        <strong>
            {{ $message }}
        </strong>
    </div>

@endif
<!-- DataTales Example -->
<div class="card shadow my-4">
    <div
        class="card-header py-3 d-flex align-items-center justify-content-between">
        <h6 class="m-0 font-weight-bold text-primary">Cadastrar
            Centro de Pescas</h6>
    </div>
   
    <div class="card-body">

        <div class="row">
            <form action="{{ route('centros-de-pesca.store') }}" method="POST">
                @csrf
                <div class="col-12 mb-3">
                    <label for="provincia" class="form-label">Província</label>
                    <select name="provincia" id="provincia"
                        class="form-select @error('provincia') is-invalid @enderror">
                        <option value="Maputo">Maputo</option>
                        <option value="Gaza">Gaza</option>
                        <option value="Inhambane">Inhambane</option>
                        <option value="Manica">Manica</option>
                    </select>
                    @error('provincia')

                    <span class="text text-danger">
                        <strong>
                            {{ $message }}
                        </strong>
                    </span>

                    @enderror
                </div>
                <div class="col-12 mb-3">
                    <label for="distrito" class="form-label">Distrito</label>
                    <select name="distrito" id="distrito"
                        class="form-select @error('distrito') is-invalid @enderror">
                        <option value="KaNyaka">KaNyaka</option>
                        <option value="KaTembe">KaTembe</option>
                        <option value="KaMpfumo">KaMpfumo</option>
                        <option value="KaMavota">KaMavota</option>
                    </select>
                    @error('distrito')

                    <span class="text text-danger">
                        <strong>
                            {{ $message }}
                        </strong>
                    </span>

                    @enderror
                </div>
                <div class="col-12 mb-3">
                    <label for="centroDePesca" class="form-label">Centro de
                        Pescas</label>
                    <input type="text" name="centro_de_pesca" id="centroDePesca"
                        class="form-control @error('centro_de_pesca') is-invalid @enderror"
                        value="{{ old('centro_de_pesca') }}">

                    @error('centro_de_pesca')

                    <span class="text text-danger">
                        <strong>
                            {{ $message }}
                        </strong>
                    </span>

                    @enderror
                </div>
                <div class="col-12 mb-3">
                    <button type="submit"
                        class="form-control btn btn-primary">Cadastrar</button>
                </div>
            </form>
        </div>

    </div>
</div>
@endsection