@extends('layouts.app')

@section('title', 'Sistema de Licenciamento de Pescas - Centros de Pescas')

@section('content')
<!-- Page Heading -->
<h1 class="h4 mb-4 text-gray-800">Centros de Pesca</h1>
@if($message = Session('error'))

<div class="alert alert-success">
    <strong>
        {{ $message }}
    </strong>
</div>

@endif

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div
        class="card-header py-3 d-flex align-items-center justify-content-between">
        <h6 class="m-0 font-weight-bold text-primary">Lista de Centros de Pesca
            de Maputo</h6>
        <a href="{{ route('centros-de-pesca.create') }}"
            class="btn btn-warning rounded-sm" title="Adicionar Centro de Pesca"><i
                class="fa fa-plus"></i> Adicionar Centro de Pesca</a>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover table-striped" id="dataTable"
                width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Província</th>
                        <th>Distrito</th>
                        <th>Centro de Pesca</th>
                        <th>Acções</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($centrosDePesca as $centroDePesca)
                    @if(!$centroDePesca->estado)
                    <tr>
                        <td>{{ $centroDePesca->id }}</td>
                        <td>{{ $centroDePesca->provincia }}</td>
                        <td>{{ $centroDePesca->distrito }}</td>
                        <td>{{ $centroDePesca->centro_de_pesca }}</td>
                        <td>
                            <form
                                action="{{ route('centros-de-pesca.destroy', $centroDePesca->id) }}"
                                method="POST">
                                @method('DELETE')
                                @csrf
                                <a
                                    href="{{ route('centros-de-pesca.show', $centroDePesca->id) }}"
                                    class="btn btn-success btn-sm"><i
                                        class="fa fa-eye"></i></a>
                                <a
                                    href="{{ route('centros-de-pesca.edit', $centroDePesca->id) }}"
                                    class="btn btn-primary btn-sm"><i
                                        class="fa fa-edit"></i></a>
                                @can('admin_access')
                                <button type="submit"
                                    class="btn btn-danger btn-sm"><i
                                        class="fa fa-trash"></i></button>
                                @endcan
                            </form>
                        </td>
                    </tr>
                    @endif
                    @endforeach
                </tbody>
            </table>
        </div>
        {{ $centrosDePesca->onEachSide(3)->links() }}
    </div>
</div>
@endsection