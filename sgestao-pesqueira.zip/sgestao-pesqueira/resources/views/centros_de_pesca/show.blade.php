@extends('layouts.app')

@section('title', 'Sistema de Licenciamento de Pescas - Sobre O Centro De Pesca')

@section('content')
<!-- Page Heading -->

<h1 class="h4 text text-info" style="text-transform: uppercase;">Centro De Pesca {{
    $centroDePesca->centro_de_pesca }}</h1>
<!-- DataTales Example -->
<div class="card shadow mb-4 mt-5">
    <div
        class="card-header py-3 d-flex align-items-center justify-content-between">
        <h6 class="m-0 font-weight-bold">Detalhes sobre centro de pesca</h6>
    </div>
    <div class="card-body">

        <div class="row col-12 col-md-12">
            <div class="table-responsive">
                <table class="table table-striped">
                    <tr>
                        <td>Id</td>
                        <td>{{ $centroDePesca->id }}</td>
                    </tr>
                    <tr>
                        <td>Província</td>
                        <td>{{ $centroDePesca->provincia }}</td>
                    </tr>
                    <tr>
                        <td>Distrito</td>
                        <td>{{ $centroDePesca->distrito }}</td>
                    </tr>
                    <tr>
                        <td>Nome Do Centro De Pesca</td>
                        <td>{{ $centroDePesca->centro_de_pesca }}</td>
                    </tr>
                    <tr>
                        <td>Data de Cadastro</td>
                        <td>{{ $centroDePesca->created_at }}</td>
                    </tr>
                    <tr>
                        <td>Data de Actualizacao</td>
                        <td>{{ $centroDePesca->updated_at }}</td>
                    </tr>
                </table>
            </div>
        </div>

    </div>
</div>
@endsection