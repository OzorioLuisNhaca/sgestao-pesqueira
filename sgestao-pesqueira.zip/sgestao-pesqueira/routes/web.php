<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\ArteController;
use App\Http\Controllers\CentroDePescaController;
use App\Http\Controllers\EmbarcacaoController;
use App\Http\Controllers\PescadorController;
use App\Http\Controllers\ArteDoPescadorController;
use App\Http\Controllers\EmbarcacaoDoPescadorController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\PagamentoController;
use App\Http\Controllers\TestesController;
use App\Http\Controllers\DocumentsController;

use App\Http\Controllers\LogController;
use App\Models\Pagamento;
use League\CommonMark\Renderer\Block\DocumentRenderer;
use Whoops\Run;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('auth.login');
});

Auth::routes();

Route::get('/acesso-negado', [HomeController::class, 'accessDenied'])->name('accessdenied');
Route::get('/testes/grafico', [TestesController::class, 'graphic'])->name('testes.graphic');
Route::get('/testes/paginacao', [TestesController::class, 'paginacao'])->name('paginacao.graphic');
Route::get('/testes/hash', [TestesController::class, 'hash'])->name('hash');

Route::middleware('auth')->group(function () {
    
    Route::get('/home', [HomeController::class, 'index'])->name('home');
    Route::get('/documento/pdf', [DocumentsController::class, 'pdfDocument'])->name('documento.pdf');
    Route::get('/documento/recibo/{id}', [DocumentsController::class, 'recibo'])->name('documento.recibo');
    Route::get('/documento/sobre_o_centro_de_pescas/{id}', [DocumentsController::class, 'sobre_centro_de_pescas'])->name('documento.sobre_centro_de_pescas');
    Route::get('/testes/ajax', [LogController::class, 'index'])->name('testes.ajax');
    Route::post('store', [LogController::class, 'store']);
    
    Route::middleware('admin')->group(function () {

        Route::controller(RegisterController::class)->group(function () {
            Route::post('/cadastrar-utilizador', 'register')->name('register');  
        });  

        Route::controller(UserController::class)->group(function () {
    
            Route::get('/utilizadores', 'index')->name('utilizadores.index')->middleware('admin');
            Route::get('/utilizadores/cadastrar', 'create')->name('utilizadores.create')->middleware('admin');
            Route::delete('/utilizadores/{id}', 'destroy')->name('utilizadores.destroy');
            Route::get('/utilizadores/editar/{id}', 'edit')->name('utilizadores.edit');
            Route::put('/utilizadores/{id}', 'update')->name('utilizadores.update');
        
        });
            
    });


    Route::controller(ArteController::class)->group(function () {
        
        Route::get('/artes', 'index')->name('artes.index');
        Route::get('/artes/cadastrar', 'create')->name('artes.create');
        Route::post('/artes', 'store')->name('artes.store');
        Route::delete('/artes/{id}', 'destroy')->name('artes.destroy');
        Route::get('/artes/ver-detalhes/{id}', 'show')->name('artes.show');
        Route::get('/artes/editar/{id}', 'edit')->name('artes.edit');
        Route::put('/artes/{id}', 'update')->name('artes.update');
            
    });

    Route::controller(CentroDePescaController::class)->group(function () {
    
        Route::get('/centros-de-pesca', 'index')->name('centros-de-pesca.index');
        Route::get('/centros-de-pesca/cadastrar', 'create')->name('centros-de-pesca.create');
        Route::post('/centros-de-pesca', 'store')->name('centros-de-pesca.store');
        Route::delete('/centros-de-pesca/{id}', 'destroy')->name('centros-de-pesca.destroy');
        Route::get('/centros-de-pesca/ver-detalhes/{id}', 'show')->name('centros-de-pesca.show');
        Route::get('/centros-de-pesca/editar/{id}', 'edit')->name('centros-de-pesca.edit');
        Route::put('/centros-de-pesca/{id}', 'update')->name('centros-de-pesca.update');
        Route::get('/centros-de-pesca/estatisticas', 'show_statistics')->name('centros-de-pesca.show_statistics');
    
    });
    
    Route::controller(EmbarcacaoController::class)->group(function () {
    
        Route::get('/embarcacoes', 'index')->name('embarcacoes.index');
        Route::get('/embarcacoes/cadastrar', 'create')->name('embarcacoes.create');
        Route::post('/embarcacoes', 'store')->name('embarcacoes.store');
        Route::delete('/embarcacoes/{id}', 'destroy')->name('embarcacoes.destroy');
        Route::get('/embarcacoes/ver-detalhes/{id}', 'show')->name('embarcacoes.show');
        Route::get('/embarcacoes/editar/{id}', 'edit')->name('embarcacoes.edit');
        Route::put('/embarcacoes/{id}', 'update')->name('embarcacoes.update');
    
    });
    
    Route::controller(PescadorController::class)->group(function () {
    
        Route::get('/pescadores', 'index')->name('pescadores.index');
        Route::get('/pescadores/cadastrar', 'create')->name('pescadores.create');
        Route::post('/pescadores', 'store')->name('pescadores.store');
        Route::delete('/pescadores/{id}', 'destroy')->name('pescadores.destroy');
        Route::get('/pescadores/ver-detalhes/{id}', 'show')->name('pescadores.show');
        Route::get('/pescadores/editar/{id}', 'edit')->name('pescadores.edit');
        Route::put('/pescadores/{id}', 'update')->name('pescadores.update');
    
    });
    
    Route::controller(ArteDoPescadorController::class)->group(function () {
    
        Route::get('/pescadores/arte-do-pescador/cadastrar', 'create')->name('arte-do-pescador.create');
        Route::get('/pescadores/arte-do-pescador/adicionar/{idPescador}/{idEmbarcao}', 'adicionar')->name('arte-do-pescador.adicionar');
        Route::post('/arte-do-pescador', 'store')->name('arte-do-pescador.store');
        Route::delete('/arte-do-pescador/{id}', 'destroy')->name('arte-do-pescador.destroy');
    
    });
    
    Route::controller(EmbarcacaoDoPescadorController::class)->group(function () {
    
        Route::get('/pescadores/embarcacao-do-pescador/cadastrar', 'create')->name('embarcacao-do-pescador.create');
        Route::post('/embarcacao-do-pescador', 'store')->name('embarcacao-do-pescador.store');
        Route::delete('/embarcacao-do-pescador/{id}', 'destroy')->name('embarcacao-do-pescador.destroy');
        Route::get('/pescadores/embarcacao-do-pescador/editar/{id}', 'edit')->name('embarcacao-do-pescador.edit');
        Route::put('/pescadores/embarcacao-do-pescador/{id}', 'update')->name('embarcacao-do-pescador.update');
    
    });

    Route::controller(PagamentoController::class)->group(function () {
    
        Route::get('/pagamentos/emitir-recibo/{id}', 'create')->name('pagamentos.create');
        Route::get('/pagamentos/gerar-recibos', 'gerar_recibos')->name('pagamentos.gerar_recibos');
        Route::get('/pagamentos/recibo_do_pescador/{id}', 'gerar_recibo_do_pescador')->name('pagamentos.gerar_recibo_do_pescador');
        Route::put('/pagamentos/{id}', 'store')->name('pagamentos.store');
    
    });
    
    

});
